// Shared helpers used by both the content script and the popup.
(() => {
  const DEFAULTS = {
    cc: '92',          // default country code (Pakistan), used for local numbers that start with 0
    max: 100,          // max leads per run
    deep: true,        // open each listing to get phone + website
    emails: true,      // look for emails on the website
    onlyEmail: false,  // filter: only leads with an email
    onlyPhone: false,  // filter: only leads with a phone
    noWebsite: false,  // filter: leads without a website (best for web/marketing services)
    hideContacted: false, // filter: hide leads you already opened WhatsApp / Gmail / SMS / Call for
    // Outreach templates. {name} {category} {sender} are filled in per lead. Nothing is sent automatically.
    sender: '',
    msgWa: "Assalam o Alaikum! I came across {name} on Google Maps. I help local businesses get a simple website and more customers online, and I can prepare a free demo for you. Would you like to see it?\n{sender}",
    emailSubject: 'A quick idea for {name}',
    emailBody: "Assalam o Alaikum,\n\nI came across {name} on Google Maps and wanted to reach out. I help local businesses get a simple website and more customers online, and I can prepare a free demo for you.\n\nWould you like to see it? If this isn't relevant, just let me know and I won't contact you again.\n\nRegards,\n{sender}"
  };

  // [CSV header, lead field]. Order is part of the export format; do not reorder.
  const COLUMNS = [
    ['Name', 'name'], ['Category', 'category'], ['Phone', 'phone'], ['Email', 'email'], ['WhatsApp', '__wa'],
    ['Website', 'website'], ['Address', 'address'], ['Rating', 'rating'], ['Reviews', 'reviews'],
    ['Maps URL', 'url'], ['Latitude', 'lat'], ['Longitude', 'lng'], ['Search', 'query'], ['Collected', 'addedAt']
  ];

  /* ------------------------------ phones ------------------------------ */

  // Calling code -> shape of the national number (digits after the code). Used to validate numbers and to
  // recognise digits-only international numbers safely. Codes not listed are only accepted with + or 00.
  const CC_RULES = {
    '92':  { len: [9, 10], first: /^[2-9]/ },   // Pakistan: mobile 3xx xxxxxxx (10), landlines 9-10 digits
    '1':   { len: [10],    first: /^[2-9]/ },   // US / Canada
    '44':  { len: [9, 10], first: /^[1-9]/ },   // United Kingdom
    '91':  { len: [10],    first: /^[6-9]/ },   // India mobiles
    '971': { len: [8, 9],  first: /^[2-9]/ },   // UAE
    '966': { len: [8, 9],  first: /^[1-9]/ }    // Saudi Arabia
  };
  const KNOWN_CODES = Object.keys(CC_RULES).sort((a, b) => b.length - a.length);

  function nationalOk(code, nat) {
    const r = CC_RULES[code];
    if (!r) return nat.length >= 6 && nat.length <= 13 && nat[0] !== '0';
    return r.len.includes(nat.length) && r.first.test(nat);
  }

  function validInternational(intl) {
    if (!/^[1-9]\d{7,14}$/.test(intl)) return false;   // E.164: max 15 digits, no leading 0
    if (/^(\d)\1+$/.test(intl)) return false;           // 1111111111 etc.
    const code = KNOWN_CODES.find(c => intl.startsWith(c));
    return code ? nationalOk(code, intl.slice(code.length)) : true;
  }

  // A digits-only number with no +, 0 or 00 prefix. Only accepted when it clearly starts with the default
  // country code or a known calling code AND the rest has a valid national length. Otherwise ''.
  function digitsOnlyInternational(d, ccd) {
    const codes = [];
    if (ccd) codes.push(ccd);
    for (const c of KNOWN_CODES) if (c !== ccd) codes.push(c);
    for (const c of codes) if (d.startsWith(c) && nationalOk(c, d.slice(c.length))) return d;
    return '';
  }

  // Returns international digits (no +) or '' when the input is not a safely recognisable phone number.
  // A well-formed number says nothing about whether the person has WhatsApp.
  function normalizePhone(phone, cc) {
    const raw = String(phone == null ? '' : phone).trim();
    if (!raw || raw.length > 40) return '';
    if (/[^\d\s()+\-.\u00a0\u2010-\u2013]/.test(raw)) return '';        // letters, extensions, symbols
    const pluses = (raw.match(/\+/g) || []).length;
    if (pluses > 1 || (pluses === 1 && !/^[\s(]*\+/.test(raw))) return '';
    const d = raw.replace(/\D/g, '');
    if (!d) return '';
    const ccd = String(cc == null ? '' : cc).replace(/\D/g, '');
    let intl;
    if (pluses === 1) intl = d;
    else if (d.startsWith('00')) intl = d.slice(2);
    else if (d.startsWith('0')) { if (!ccd) return ''; intl = ccd + d.slice(1); }   // local number
    else intl = digitsOnlyInternational(d, ccd);
    return validInternational(intl) ? intl : '';
  }

  // The one place WhatsApp links are built. A valid format does not prove a WhatsApp account exists.
  function whatsappLink(phone, cc) {
    const d = normalizePhone(phone, cc);
    return d ? 'https://wa.me/' + d : '';
  }

  /* --------------------------- Maps card parsing --------------------------- */

  const SKIP_TOKEN = [
    /^(open|closed|opens|closes|closing|temporarily|permanently|open 24)/i,
    /^(dine-in|takeaway|delivery|drive-through|no delivery|no takeaway|no dine-in|curbside pickup|kerbside pickup|in-store shopping|online appointments)$/i,
    /^(website|directions|order online|call|reserve a table|sponsored|ad|menu|book)$/i,
    /^[$£€₨]/, /^rs\b/i
  ];

  const norm = s => String(s || '').toLowerCase().replace(/\s+/g, ' ').trim();

  // Classifies one text token from a listing card:
  // 'rating' | 'count' | 'phone' | 'number' (digits we can't place; discarded) | 'text'
  function classifyToken(t, cc) {
    if (/^\d(\.\d)?$/.test(t)) return 'rating';                       // 4.5
    if (/^\(\s*[\d,.\s]+\)$/.test(t)) return 'count';                  // (120) (1,234)
    if (/^\d{1,3}(,\d{3})+$/.test(t)) return 'count';                  // 1,234
    if (/^\d{1,6}$/.test(t)) return 'number';                          // 463, 46000: address/postcode fragments
    if (/^[+(]?\d[\d\s().\-]*\d$/.test(t)) {
      const digits = t.replace(/\D/g, '').length;
      if (normalizePhone(t, cc)) return 'phone';                        // 03001234567, 0300-1234567, +92 300 ...
      if (/[\s()\-]/.test(t) && digits >= 8 && digits <= 15) return 'phone'; // formatted numbers (e.g. 111-222-333) as before
      return 'number';                                                  // long digit run that is not a valid phone
    }
    return 'text';
  }

  // lines: visible text lines of the card. ratingLabel: aria-label of the star element. tel: href of a tel: link.
  // A tel: link is preferred over any text guess.
  function parseCardText({ name, lines, ratingLabel, tel, cc }) {
    name = String(name || '');
    lines = (lines || []).map(s => String(s).trim()).filter(Boolean);

    let rating = '', reviews = '';
    const nums = String(ratingLabel || '').match(/\d[\d,.]*/g) || [];
    if (nums[0]) rating = nums[0].replace(',', '.');
    if (nums[1]) reviews = nums[1].replace(/[,.]/g, '');
    if (!reviews) {
      const r = lines.find(l => /^\(\s*[\d,]+\s*\)$/.test(l));
      if (r) reviews = r.replace(/\D/g, '');
    }

    let phone = '';
    if (tel) {
      let t = String(tel).replace(/^tel:/i, '');
      try { t = decodeURIComponent(t); } catch (e) { /* keep raw */ }
      t = t.trim();
      if (normalizePhone(t, cc)) phone = t;
    }

    const nameParts = norm(name).split(/\s*[·⋅•|]\s*/);
    const tokens = lines.join(' · ').split(/\s*[·⋅•|]\s*/).map(s => s.trim()).filter(Boolean);
    const rest = [];
    for (const t of tokens) {
      if (norm(t) === norm(name) || (t.length >= 3 && nameParts.includes(norm(t)))) continue;
      const kind = classifyToken(t, cc);
      if (kind === 'rating' || kind === 'count' || kind === 'number') continue;
      if (kind === 'phone') { phone = phone || t; continue; }
      if (SKIP_TOKEN.some(re => re.test(t))) continue;
      rest.push(t);
    }
    const category = rest[0] || '';
    const address = rest.slice(1).find(t => /\d|,|road|street|st\b|block|sector|plaza|market/i.test(t)) || rest[1] || '';
    return { rating, reviews, phone, category, address };
  }

  // Stable identity of a place: the 0x..:0x.. id inside the Maps URL, else the URL path.
  function placeKey(href) {
    href = String(href || '');
    const m = href.match(/!1s(0x[0-9a-f]+:0x[0-9a-f]+)/i);
    if (m) return m[1];
    try { return decodeURIComponent(new URL(href).pathname).slice(0, 160); } catch (e) { return href.slice(0, 160); }
  }
  function placeCoords(href) {
    const m = String(href || '').match(/!3d(-?[\d.]+)!4d(-?[\d.]+)/);
    return m ? { lat: m[1], lng: m[2] } : { lat: '', lng: '' };
  }

  const hasContact = l => !!(l.contacted && Object.keys(l.contacted).length);

  function applyFilters(list, s) {
    return list.filter(l =>
      (!s.hideContacted || !hasContact(l)) &&
      (!s.onlyPhone || l.phone) &&
      (!s.onlyEmail || l.email) &&
      (!s.noWebsite || (l.detailed && !l.website))
    );
  }

  /* ----------------------------- outreach links ----------------------------- */
  // These build links only. The browser or app opens with the text filled in and the person presses send,
  // one lead at a time. Nothing is sent automatically.

  const clean = v => String(v == null ? '' : v).replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/g, '').trim();

  function fillTemplate(tpl, lead, s) {
    const vars = { name: clean(lead.name), category: clean(lead.category), sender: clean(s && s.sender) };
    return String(tpl == null ? '' : tpl)
      .replace(/\{(name|category|sender)\}/gi, (_, k) => vars[k.toLowerCase()])
      .replace(/[ \t]+\n/g, '\n').replace(/\n{3,}/g, '\n\n').trim();
  }

  const EMAIL_RE = /^[^@\s,;<>"']+@[^@\s,;<>"']+\.[^@\s,;<>"']+$/;
  function firstEmail(v) {
    return String(v || '').split(/[;,]\s*/).map(x => x.trim()).find(e => e.length <= 254 && EMAIL_RE.test(e)) || '';
  }

  // { whatsapp, sms, call, gmail } URLs; an empty string means "not available for this lead".
  function outreachLinks(lead, s) {
    s = s || {};
    const enc = encodeURIComponent;
    const digits = normalizePhone(lead.phone, s.cc);
    const msg = fillTemplate(s.msgWa || DEFAULTS.msgWa, lead, s).slice(0, 1000);
    const to = firstEmail(lead.email);
    const subject = fillTemplate(s.emailSubject || DEFAULTS.emailSubject, lead, s).replace(/\s+/g, ' ').slice(0, 200);
    const body = fillTemplate(s.emailBody || DEFAULTS.emailBody, lead, s).slice(0, 1500);
    return {
      whatsapp: digits ? `https://wa.me/${digits}?text=${enc(msg)}` : '',
      sms: digits ? `sms:+${digits}?body=${enc(msg)}` : '',
      call: digits ? `tel:+${digits}` : '',
      gmail: to ? `https://mail.google.com/mail/?view=cm&fs=1&to=${enc(to)}&su=${enc(subject)}&body=${enc(body)}` : ''
    };
  }

  /* ------------------------------- CSV ------------------------------- */

  // Characters a spreadsheet may ignore before a formula: whitespace, control chars, zero-width chars.
  const FORMULA_START = /^[\u0000-\u0020\u00a0\u200b-\u200d\u2060\ufeff]*[=+\-@]/;
  const TAB_OR_CR_START = /^[\t\r]/;

  // Defuse a spreadsheet formula by prefixing an apostrophe. Quoting a CSV cell does NOT stop a formula.
  function neutralize(v) {
    return (FORMULA_START.test(v) || TAB_OR_CR_START.test(v)) ? "'" + v : v;
  }
  function csvEscape(v) {
    return /[",\r\n]/.test(v) ? '"' + v.replace(/"/g, '""') + '"' : v;
  }
  const textCell = v => csvEscape(neutralize(String(v == null ? '' : v)));

  // Only values that pass these checks are written as bare numbers; everything else is treated as text.
  const NUMERIC = {
    rating:  v => /^[0-5](\.\d{1,2})?$/.test(v),
    reviews: v => /^\d{1,9}$/.test(v),
    lat:     v => /^-?\d{1,2}(\.\d+)?$/.test(v) && Math.abs(Number(v)) <= 90,
    lng:     v => /^-?\d{1,3}(\.\d+)?$/.test(v) && Math.abs(Number(v)) <= 180
  };
  function numberCell(field, v) {
    v = String(v == null ? '' : v).trim();
    if (!v) return '';
    return NUMERIC[field](v) ? v : textCell(v);
  }

  // Phone-shaped values contain only + digits space ( ) . - so they can never be a formula and are written as is
  // (leading 0 and + preserved). Digits-only values get one space, because spreadsheet apps turn bare digit runs
  // into numbers and drop the leading 0 / +. Anything not phone-shaped is treated as untrusted text.
  function phoneCell(v, cc) {
    v = String(v == null ? '' : v).trim();
    if (!v) return '';
    if (!/^\+?\d[\d\s().\-]{4,30}$/.test(v)) return textCell(v);
    if (/^\+?\d+$/.test(v)) {
      const intl = normalizePhone(v, cc);
      if (v.startsWith('0') && !v.startsWith('00') && v.length >= 10) v = v.slice(0, 4) + ' ' + v.slice(4);
      else if (intl) {
        const code = KNOWN_CODES.find(c => intl.startsWith(c));
        if (code) v = '+' + code + ' ' + intl.slice(code.length);
      }
    }
    return csvEscape(v);
  }

  function toCSV(list, s) {
    const cc = s && s.cc;
    const rows = [COLUMNS.map(c => c[0])];
    for (const l of list) {
      rows.push(COLUMNS.map(([, f]) => {
        if (f === '__wa') return csvEscape(whatsappLink(l.phone, cc));                      // built by us from validated digits
        if (f === 'addedAt') return l.addedAt ? new Date(l.addedAt).toISOString().slice(0, 16).replace('T', ' ') : '';
        if (f === 'phone') return phoneCell(l.phone, cc);
        if (NUMERIC[f]) return numberCell(f, l[f]);
        return textCell(l[f]);                                                              // everything else is untrusted text
      }));
    }
    return rows.map(r => r.join(',')).join('\r\n');
  }

  // UTF-8 BOM so Excel reads non-Latin names correctly.
  const csvFileText = (list, s) => '\ufeff' + toCSV(list, s);

  function download(list, s) {
    const q = (list.find(l => l.query) || {}).query || 'maps';
    const slug = String(q).toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '').slice(0, 40) || 'maps';
    const name = `leads-${slug}-${new Date().toISOString().slice(0, 10)}.csv`;
    const blob = new Blob([csvFileText(list, s)], { type: 'text/csv;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = name;
    document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 3000);
  }

  /* ------------------------------ license UI text ------------------------------ */

  function lockMessage(l) {
    switch (l.state) {
      case 'signedout': return 'Sign in to your Haseeb Extensions account. No license key is needed.';
      case 'pending': return 'Your request is waiting for owner approval. Open My access to review your details.';
      case 'blocked': return 'Access has been blocked by Haseeb Crafts. Contact the owner for help.';
      case 'expired': return 'Your access has expired. Contact Haseeb Crafts to renew.';
      case 'unregistered': return 'Open My access and submit your name and contact to request approval.';
      case 'offline': return 'Could not verify access online. Check your connection and press Refresh.';
      default: return 'Open My access or sign in again to check your account.';
    }
  }

  globalThis.LF = {
    lockMessage, DEFAULTS, COLUMNS, normalizePhone, whatsappLink, classifyToken, parseCardText,
    placeKey, placeCoords, applyFilters, fillTemplate, outreachLinks, firstEmail, toCSV, csvFileText, download
  };
})();
