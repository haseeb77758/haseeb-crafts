// Public service address only; no private keys or passwords.
globalThis.HC_ACCESS_ORIGIN = 'https://haseeb-extensions-access.therealhaseeb7890.chatgpt.site';
