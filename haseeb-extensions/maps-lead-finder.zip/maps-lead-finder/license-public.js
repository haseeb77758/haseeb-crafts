// LICENSE CONFIGURATION (read by background.js)
//
// RELEASE mode (the default, and what customers must get):
//   A valid PUBLIC key must be installed here. Replace this whole file with the license-public.js that your
//   license control panel generates ("Download license-public.js"). Until then this copy shows
//   "License configuration required" and stays locked.
//
// DEVELOPMENT mode (owner only, never ship it): change LF_MODE to "development" to be allowed to paste a public key
//   into the panel for testing. The panel is clearly labelled DEVELOPMENT.
//
// This file must only ever contain the PUBLIC key. A key that includes private material is rejected.
globalThis.LF_MODE = "release";
globalThis.LF_PUBLIC_KEY = null;
globalThis.LF_VENDOR = "";
globalThis.LF_STATUS_URL = "";
