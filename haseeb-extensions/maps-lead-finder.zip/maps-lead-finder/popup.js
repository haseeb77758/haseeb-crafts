const $ = id => document.getElementById(id);

async function load() {
  const r = await chrome.storage.local.get(['leads', 'settings']);
  return { leads: Object.values(r.leads || {}), settings: { ...LF.DEFAULTS, ...(r.settings || {}) } };
}

let lic = { ok: false };

async function checkLicense() {
  try { lic = (await chrome.runtime.sendMessage({ type: 'lf-license' })) || { ok: false, state: 'error' }; }
  catch (e) { lic = { ok: false, state: 'error' }; }
  const box = $('lic'), msg = $('licmsg');
  box.classList.toggle('ok', !!lic.ok);
  if (lic.ok) {
    $('licform').hidden = true;
    $('setupform').hidden = true;
    $('deact').hidden = false;
    {
      const who = lic.name ? `${lic.name} (${lic.email})` : lic.email;
      msg.textContent = `Licensed to ${who}` + (lic.expires ? `, until ${new Date(lic.expires).toISOString().slice(0, 10)}` : '') + '.'
        + (lic.mode === 'development' ? ' DEVELOPMENT MODE: not for customers.' : lic.owner ? ' Owner copy.' : '');
    }
  } else {
    const unconf = lic.state === 'config' || lic.state === 'nokey';
    $('licform').hidden = lic.state === 'error';
    $('setupform').hidden = !(unconf && lic.canSetup);
    $('key').disabled = $('act').disabled = $('paste').disabled = unconf;
    $('deact').hidden = true;
    msg.textContent = LF.lockMessage(lic);
  }
  $('csv').disabled = $('clear').disabled = !lic.ok;
}

$('savepub').onclick = async () => {
  const text = $('pub').value.trim();
  if (!text) return;
  try {
    const r = await chrome.runtime.sendMessage({ type: 'lf-setup', text });
    if (r && r.state === 'badsetup') { $('licmsg').textContent = LF.lockMessage(r); return; }
  } catch (e) { /* handled by checkLicense */ }
  await checkLicense();
};

$('paste').onclick = async () => {
  try { $('key').value = (await navigator.clipboard.readText()).trim(); }
  catch (e) { $('licmsg').textContent = 'The browser blocked pasting. Click in the box and press Ctrl+V.'; }
};

$('deact').onclick = async () => {
  if (!confirm('Remove the license from this browser? You can activate it again with your key.')) return;
  try { await chrome.runtime.sendMessage({ type: 'lf-deactivate' }); } catch (e) { /* handled by checkLicense */ }
  await checkLicense();
};

$('act').onclick = async () => {
  const key = $('key').value.trim();
  if (!key) return;
  try {
    const r = await chrome.runtime.sendMessage({ type: 'lf-activate', key });
    if (r && !r.ok) { $('licmsg').textContent = LF.lockMessage(r); return; }
  } catch (e) { /* handled by checkLicense */ }
  await checkLicense();
};

async function refresh() {
  const { leads } = await load();
  $('total').textContent = leads.length;
  $('phones').textContent = leads.filter(l => l.phone).length;
  $('emails').textContent = leads.filter(l => l.email).length;
  $('nosite').textContent = leads.filter(l => l.detailed && !l.website).length;
}

$('open').onclick = async () => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  try {
    await chrome.tabs.sendMessage(tab.id, { type: 'lf-toggle' });
  } catch (e) {
    await chrome.tabs.create({ url: 'https://www.google.com/maps' });
  }
  window.close();
};

$('csv').onclick = async () => {
  if (!lic.ok) return;
  const { leads, settings } = await load();
  const list = LF.applyFilters(leads, settings).sort((a, b) => b.addedAt - a.addedAt);
  if (!list.length) return;
  LF.download(list, settings);
};

$('clear').onclick = async () => {
  if (!confirm('Delete all saved leads?')) return;
  await chrome.storage.local.set({ leads: {} });
  checkLicense();
refresh();
};

checkLicense();
refresh();
