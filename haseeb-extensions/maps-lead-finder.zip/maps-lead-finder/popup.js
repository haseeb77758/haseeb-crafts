const $ = id => document.getElementById(id);
let access = { ok: false };
async function check() {
  try { access = await chrome.runtime.sendMessage({ type: 'lf-license', force: true }); }
  catch { access = { ok: false, state: 'offline' }; }
  if(!access) access = {ok:false,state:'offline'};
  $('account').textContent = access.ok ? (access.name || access.email || 'Approved account') : (access.email || 'Account access');
  $('message').textContent = access.ok ? 'Approved' + (access.email ? ' · ' + access.email : '') : LF.lockMessage(access);
  $('signin').hidden = !!access.ok;
  $('signin').textContent = access.state === 'linking' ? 'Continue sign-in' : 'Sign in';
  $('signout').hidden = access.state === 'signedout';
  for (const id of ['open', 'csv', 'clear']) $(id).disabled = !access.ok;
}
async function load() {
  const r = await chrome.storage.local.get(['leads','settings']);
  return { leads:Object.values(r.leads || {}), settings:{...LF.DEFAULTS,...(r.settings || {})} };
}
async function refresh() {
  const {leads} = await load();
  $('total').textContent = leads.length;
  $('phones').textContent = leads.filter(l=>l.phone).length;
  $('emails').textContent = leads.filter(l=>l.email).length;
  $('nosite').textContent = leads.filter(l=>l.detailed && !l.website).length;
}
$('signin').onclick = () => chrome.runtime.sendMessage({type:'hc-signin'});
$('portal').onclick = () => chrome.runtime.sendMessage({type:'hc-portal'});
$('refresh').onclick = async () => { $('refresh').disabled=true; $('message').textContent='Checking online access…'; try {await check();} finally {$('refresh').disabled=false;} };
$('signout').onclick = async () => { await chrome.runtime.sendMessage({type:'lf-deactivate'});await check(); };
$('open').onclick = async () => {
  await check(); if(!access.ok)return;
  const [tab] = await chrome.tabs.query({active:true,currentWindow:true});
  let mapsTab = false;
  try { const u=new URL(tab?.url || ''); mapsTab=/^(www\.google\.com|www\.google\.com\.pk|maps\.google\.com)$/.test(u.hostname) && (u.pathname.startsWith('/maps') || u.hostname==='maps.google.com'); } catch {}
  if (mapsTab) {
    try { const result=await chrome.tabs.sendMessage(tab.id,{type:'lf-show'}); if(!result?.ok) await chrome.tabs.reload(tab.id); }
    catch { await chrome.tabs.reload(tab.id); }
  } else await chrome.tabs.create({url:'https://www.google.com/maps'});

  window.close();
};
$('csv').onclick = async () => {
  await check(); if(!access.ok)return;
  const {leads,settings}=await load();
  const list=LF.applyFilters(leads,settings).sort((a,b)=>b.addedAt-a.addedAt);
  if(list.length)LF.download(list,settings);
};
$('clear').onclick = async () => {
  await check(); if(!access.ok)return;
  if(confirm('Delete all saved leads from this browser?')) {await chrome.storage.local.set({leads:{}});await refresh();}
};
chrome.storage.onChanged.addListener(ch=>{if(ch.hcSession || ch.hcAccess)check();if(ch.leads)refresh();});
check();refresh();

setInterval(check,3000);
