(() => {
  'use strict';
  if (window.__mapsLeadFinder) return;
  window.__mapsLeadFinder = true;
  const LF = globalThis.LF;

  /* ------------------------------------------------------------------
   * SELECTORS — if Google changes the Maps layout and something stops
   * working, this is the only place you need to fix.
   * ------------------------------------------------------------------ */
  const SEL = {
    feed: 'div[role="feed"]',
    placeLink: 'a[href*="/maps/place/"]',
    card: 'div.Nv2PK',
    phone: 'button[data-item-id^="phone"]',
    website: 'a[data-item-id="authority"]',
    address: 'button[data-item-id="address"]',
    category: 'button[jsaction*="category"]',
    infoText: '.Io6YTe',
    back: 'button[aria-label="Back"]'
  };

  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const $ = (s, r = document) => r.querySelector(s);
  const norm = s => (s || '').toLowerCase().replace(/\s+/g, ' ').trim();

  async function waitFor(fn, timeout = 6000, step = 150) {
    const t = Date.now();
    while (Date.now() - t < timeout) {
      const v = fn();
      if (v) return v;
      await sleep(step);
    }
    return null;
  }

  /* ------------------------------ state ------------------------------ */
  let leads = {};
  let settings = { ...LF.DEFAULTS };
  const run = { active: false, stop: false, keys: new Set(), query: '' };

  let saveTimer = null;
  function saveSoon() {
    clearTimeout(saveTimer);
    saveTimer = setTimeout(() => { try { chrome.storage.local.set({ leads }); } catch (e) { /* extension reloaded */ } }, 400);
  }
  function saveSettings() { try { chrome.storage.local.set({ settings }); } catch (e) { /* ignore */ } }

  /* --------------------------- page helpers --------------------------- */
  const keyOf = href => LF.placeKey(href);
  const coordsOf = href => LF.placeCoords(href);
  function currentQuery() {
    const box = $('#searchboxinput');
    if (box && box.value) return box.value.trim();
    const m = location.pathname.match(/\/maps\/search\/([^/]+)/);
    return m ? decodeURIComponent(m[1].replace(/\+/g, ' ')) : '';
  }
  function findLink(key) {
    const feed = $(SEL.feed);
    if (!feed) return null;
    for (const a of feed.querySelectorAll(SEL.placeLink)) if (keyOf(a.href) === key) return a;
    return null;
  }
  function clickBack(allowHistory) {
    const b = $(SEL.back);
    if (b) { b.click(); return true; }
    if (allowHistory) { history.back(); return true; }
    return false;
  }

  /* --------------------------- card parsing --------------------------- */
  // The text classification (rating vs review count vs phone vs address) lives in shared.js (LF.parseCardText)
  // so it can be tested without a browser. Here we only read the DOM.

  function parseCard(a) {
    const name = (a.getAttribute('aria-label') || '').trim();
    if (!name) return null;
    const card = a.closest(SEL.card) || a.parentElement || a;
    const img = card.querySelector('span[role="img"]');
    const telEl = card.querySelector('a[href^="tel:"]');          // prefer a real tel: link when the card has one
    const parsed = LF.parseCardText({
      name,
      lines: (card.innerText || '').split('\n'),
      ratingLabel: (img && img.getAttribute('aria-label')) || '',
      tel: telEl ? telEl.getAttribute('href') : '',
      cc: settings.cc
    });
    const { lat, lng } = coordsOf(a.href);
    return { name, ...parsed, url: a.href, lat, lng };
  }

  function upsert(p) {
    const old = leads[p.key];
    if (old) {
      for (const f of ['category', 'phone', 'address', 'rating', 'reviews']) if (!old[f] && p[f]) old[f] = p[f];
      old.url = p.url;
      return false;
    }
    leads[p.key] = { ...p, website: '', detailed: false, query: run.query, addedAt: Date.now() };
    return true;
  }

  function collectCards(feed, max) {
    for (const a of feed.querySelectorAll(SEL.placeLink)) {
      if (run.keys.size >= max) break;
      const key = keyOf(a.href);
      if (run.keys.has(key)) continue;
      const p = parseCard(a);
      if (!p) continue;
      p.key = key;
      run.keys.add(key);
      upsert(p);
    }
    saveSoon();
    renderSoon();
  }

  /* ----------------------------- scanning ----------------------------- */
  async function scanList(feed) {
    const max = settings.max;
    let stagnant = 0, last = -1;
    while (!run.stop) {
      collectCards(feed, max);
      const count = run.keys.size;
      setStatus(`Collecting listings… ${count}/${max}`);
      setProgress(count, max);
      if (count >= max) break;
      if (count === last) stagnant++; else { stagnant = 0; last = count; }
      const tail = (feed.innerText || '').slice(-300);
      if (/reached the end of the list|end of the list/i.test(tail)) break;
      if (stagnant >= 5) break;
      feed.scrollTo({ top: feed.scrollHeight, behavior: 'auto' });
      await sleep(1100 + Math.random() * 500);
    }
    collectCards(feed, max);
  }

  let lastDetailName = '';
  async function fetchDetails(key) {
    const lead = leads[key];
    let a = findLink(key);
    if (!a) {
      clickBack(true);
      a = await waitFor(() => findLink(key), 5000);
    }
    if (!a) return false;

    a.scrollIntoView({ block: 'center' });
    a.click();

    const want = norm(lead.name);
    const nameOk = h => { const t = norm(h.textContent); return t && (t === want || t.includes(want) || want.includes(t)); };
    const hexKey = /^0x/i.test(key);
    const findH1 = strict => [...document.querySelectorAll('h1')].find(h =>
      nameOk(h) && (!strict || !hexKey || location.href.includes(key)));

    let h1 = await waitFor(() => findH1(true), 8000);
    if (!h1 && norm(lastDetailName) !== want) h1 = findH1(false); // strict match first, so same-name branches don't get mixed up
    if (!h1) return false;

    const root = h1.closest('[role="main"]') || document;
    await waitFor(() => $(SEL.address, root) || $(SEL.phone, root) || $(SEL.website, root), 3500);
    await sleep(350);

    const text = el => {
      if (!el) return '';
      const t = $(SEL.infoText, el);
      return ((t ? t.textContent : el.getAttribute('aria-label') || el.textContent) || '').replace(/^[^:]{2,20}:\s*/, '').trim();
    };

    const pb = $(SEL.phone, root);
    let phone = '';
    if (pb) {
      const t = $(SEL.infoText, pb);
      phone = t ? t.textContent.trim() : (pb.getAttribute('data-item-id') || '').replace(/^phone:tel:/, '');
    }
    const web = $(SEL.website, root);
    const address = text($(SEL.address, root));
    const cat = ($(SEL.category, root) || {}).textContent;

    lead.phone = phone || lead.phone;
    lead.website = web ? web.href : '';
    lead.address = address || lead.address;
    lead.category = (cat || '').trim() || lead.category;
    lead.detailed = true;
    lastDetailName = lead.name;
    saveSoon();
    renderSoon();
    return true;
  }

  async function deepScan(keys) {
    const todo = keys.filter(k => leads[k] && !leads[k].detailed);
    let i = 0;
    for (const k of todo) {
      if (run.stop) break;
      setStatus(`Phone & website ${i + 1}/${todo.length} — ${leads[k].name}`);
      setProgress(i, todo.length);
      try { await fetchDetails(k); } catch (e) { console.warn('[Lead Finder] details failed', leads[k].name, e); }
      i++;
      await sleep(400 + Math.random() * 500);
    }
    setProgress(todo.length, todo.length || 1);
  }

  /* ------------------------------ emails ------------------------------ */
  const SOCIAL = /(^|\.)(facebook|fb|instagram|linkedin|twitter|x|tiktok|youtube|wa|whatsapp|linktr|t)\.(com|me|ee)$/i;

  async function findEmail(key) {
    const lead = leads[key];
    if (!lead || !lead.website || lead.emailChecked) return;
    let host = '';
    try { host = new URL(lead.website).hostname; } catch (e) { lead.emailChecked = true; return; }
    if (SOCIAL.test(host)) { lead.emailChecked = true; lead.social = lead.website; return; } // behind a login wall, can't be scraped
    try {
      const res = await chrome.runtime.sendMessage({ type: 'lf-find-email', url: lead.website });
      if (res && res.ok) { lead.email = (res.emails || []).join('; '); lead.emailChecked = true; }
    } catch (e) { /* background worker unreachable; will retry next time */ }
    saveSoon();
    renderSoon();
  }

  async function emailPass(keys) {
    const todo = keys.filter(k => leads[k] && leads[k].website && !leads[k].emailChecked);
    let next = 0, done = 0;
    const worker = async () => {
      while (next < todo.length && !run.stop) {
        const k = todo[next++];
        setStatus(`Finding emails ${done + 1}/${todo.length} — ${leads[k].name}`);
        await findEmail(k);
        done++;
        setProgress(done, todo.length);
      }
    };
    if (todo.length) await Promise.all([worker(), worker(), worker()]);
  }

  async function runEmailsOnly() {
    if (run.active || !licensed || !(await ensureAccess())) return;
    readInputs();
    run.active = true; run.stop = false;
    setRunning(true);
    try {
      const keys = Object.keys(leads);
      const pending = keys.filter(k => leads[k].website && !leads[k].emailChecked).length;
      if (!pending) { setStatus('No new websites to check for emails. Run Start with "Also get phone and website" first.', 'warn'); return; }
      await emailPass(keys);
      const found = keys.filter(k => leads[k].email).length;
      setStatus(run.stop ? 'Stopped.' : `Done — ${found} leads have an email.`, run.stop ? 'warn' : 'ok');
    } catch (e) {
      setStatus('Error: ' + e.message, 'err');
    } finally {
      run.active = false; setRunning(false); saveSoon(); render();
    }
  }

  async function startRun() {
    if (run.active || !licensed || !(await ensureAccess())) return;
    readInputs();
    run.active = true; run.stop = false; run.keys = new Set();
    setRunning(true);
    try {
      let feed = $(SEL.feed);
      if (!feed && clickBack(false)) feed = await waitFor(() => $(SEL.feed), 4000);
      if (!feed) {
        setStatus('No search results found. Search on Maps first (for example "dentist in Rawalpindi"), then press Start.', 'warn');
        return;
      }
      run.query = currentQuery();
      await scanList(feed);
      if (settings.deep && !run.stop) await deepScan([...run.keys]);
      if (settings.deep && settings.emails && !run.stop) await emailPass([...run.keys]);
      const n = run.keys.size;
      const em = [...run.keys].filter(k => leads[k] && leads[k].email).length;
      const tail = settings.deep && settings.emails ? `, ${em} with email` : '';
      setStatus(run.stop ? `Stopped — ${n} leads saved.` : `Done — ${n} leads collected${tail}.`, run.stop ? 'warn' : 'ok');
    } catch (e) {
      console.error('[Lead Finder]', e);
      setStatus('Error: ' + e.message, 'err');
    } finally {
      run.active = false;
      setRunning(false);
      saveSoon();
      render();
    }
  }

  /* ------------------------------- UI ------------------------------- */
  const LOGO = 'data:image/webp;base64,UklGRj4yAABXRUJQVlA4WAoAAAAQAAAA7wAApgAAQUxQSL8PAAAB90cmbdPWv/XtjojEU7mScNRIkiPNZOVvdvkD7nFnAET0fwLaKUDf5UJ2Au4ESLJK0UUC2UhKLUyT9GuZ38pBnYz5rT4d4/lIHyMJwD/hKQ9VLzBTQD8goLdQgT7XI9QtS/KWpoCuugpJMmkq2nclO02hbfVc2Ic1/v9Pya0+3/85M7N2vEmbIrWta9u2bdu2bdu2763dNG5jdLPJeub8fw8GO+c//3PzNCImAGQ4zxH1XZbhVDASSIV139f/4d6QqEgcdPH0e+GKaelNz7zv/97TByoOR9cLHpM+ZxwV01kLGwaP+9EfH5jgCkKOU3745oEHnX6Igj55t/8A7u2T3+smURE4eMzvnkD5BWlaVKfsy3afB3e+/DdHgYtfwtBbvnIyPOKyDZuwfJwM1JotRnjriLMnvf+OSxn5/n+f342LnMQpv/1AD0n3H5Ktu3NynvhKHpDwD3pgrQKvmvnrOcjFzMGz/vVMKPPIqr/nxbg8POefUNMi/ES1NDs1Z6PzU856FrqOTS+/RRaSPPWVMtb1mkFScemVU08CFy/H0Gf+eD4upfJnb3hylOPpL/v5NMMnqBWbyZLqfJXe6oKsXOtKN/7y32GRXlYC0gTZifc8DVIGP137wgqSSDnH+b//wBCpWPeAnV7kPPuN/WdvZ7FOJgkvgclqBC1Y8ZIPOUFJSNll21/oKMGTd286CxclBw+/4pmQwqO2fWuzJ1fT8MSge/17Spm1ZixSziwQw5zn5NNPX2qCsgBlVf+F5aSOdX/93wPkFB05xj/7p8twKX3vnfeX78hr6bDL3PV3OUg0nR++x9rxFAGVOty09/+7FKV0v3/vvVGiuDh49G3fXEHqOOW33teu2uExa5sEXpZseKwSi4Gb2GVT93qd80tpXKtj1lf9/hc4SvCo/70UcDFJ6PrgzteKEjxkq6/VfJ3KbTOPJLftM/e8OFMU7pj7+eWfGpBovLuGNfA177+4nNRx2i++/+gyLh6OwR9tvhSlDLzzsK/6rE7r12Nt2lgFsfVTTzidWF59+aOGDq1GjbrKiIbO/FN/sJrMseGKB/7kWJziIMed//ODVSSeo87txSc01M59bRGsXACjb+ceMjOzzssYmZimZ5jm1Yzmkr/4hAsTE3P/2rz7rjgXAweP2fYmhzynnICXo7G/60W4xZnYmgjRc8I0athxHmoJyQmYmhyawpog5xk9bQCfMP69ieeD6zzH0Cf+eR8oMXDOSky0aJ622jwGpAmR9K57bicaTYzmPV207DBOOJFM8OI93zwOp86SuOx/v1lDmnDUGSmiZdFe0dCIpGnu+ATGR4xWEtQKyDjzbt2kjrts2XNfcJ2UwDMPfKRMCR51Al7kbYiGRixNM19zMF5CrUzPYa0h6L90LS5l1fen31jGdY6D9008BUoMvmMaE+EqFob/8HHQNU7rw91oESDjpEdBCZ6+90/rkDpDjkt/f83FuITjfuW9KGDTj8oPYGkPas2LNspY+NQoqePijXseBa4THDxp6ifjpPCg9b6WkbsiZPr6zLN9ZS2L3TeFLa4+Pf1YsoTNf+u5Ux8dKHo+dPgtUKLr7NUgAlR0DDdXpbwO0yJcN+2VZ90liYl91rt8NDxx2l+2PhiljJ/VRciG4sEKL9FVYtFbvpqpLQjGzl6Of8Gux3FSDwrLcacDvxgnFQ8+Ca8gfLOIlienYTV+cVwz1yaQcfapx+z82NjElvkqCkka+f37oUz6ihkQIW6aahRPsaZnTgyNocWtvrhG2+VZc9mjJn770e1r30cSUsIT/c8ePML4N70nzGwSwCki2EgKawdoZ607bR+I3vGF3Re/+JzHhPbCzPt/PPB3vpaFIQHo4EJEhnbtBoZpa3pxr88BbO7ED1zWS3BP8VXv/zdXy3wYYJjNbySeXccZLO1HbRlejvIwt+u/53n8fXBhPd3Xsto/D3kfjOhemiGLRbZ3jkyrabcnV2P3NsH8JIF3gZxEgEkDg/4BYinr6d8KPaNYm6ZmsDzADKx3HIVlhOoygYA+LBqwcgQYL6E2ZZ4gUzrRW/vMGjl/pmgo1BHWnv07MMbM0+7DM2FYaAbGpn1Yu7rLDRK/6msYYMRUBxbEsiWobeVyGIEb/QDT87RZHD+CTFoY+fSpApDaZrmYsinTYnw6KOfoIc/effMuOmKhTmoXJM5MCzb25Qdk5Lx+f5JHcvjmbFFkKwQrVqIc0k2zRHi+Ll/vvvm70S88sEreCzXlAEgs2hKxbCm5ZqYYKbcs+c/L0i8/iFKC5dOJ5jWO5dJXtiAUWog9c/DzF7zz5zXlY1l4vrKWnCtDAJaX1WJjmt/ADV9+44OftxPLJUnCY7iC8pk3AanykZ/GwrLcYI7uWcrsmBG5Tv1HgfnyUI8X+U5sEbiTS/kwN0nQxsq8DHHMgDxy5GrZR++SWFimSYyca/OABpWP9axAIcEY1j7RODHqLZfBFfMzxHdojUHvOnJWicB3obYZJkSgo4lThKb3C0v68sJCmyPHsYTbCdIb3mMR8jXiK6bbJvqPZmJ6bQooH6EhE1FOKxGCStsa+uPPJ8TVw0RqbjIIC8xYi7XP0fXikkc5CTAi7X0QUliwA7VP3P0znryNiGvbn9IAbGouNKO9BoLsKX+v+LwYiNnMxiQ/+S9ehw+r3Qbg/CVf6slJLF+JogVlAsiWLUNhWZsQIMbGMnK2FCPiCsCX7tNL0CJrR6+jscOT85IyIuazAZjrngjLcG2YGsF7M5jZT76ivJaoW+X+KcrFDHH5XiwkMV1n1sroFLdJiaOvujcnM2FxW/2CxMi1VAE+tt35kDynYTDU00QcXsXUvunPfuuOucpSlM/gUkTcF+bIRYwfjaghQhaHQBw9iuoMtxmc/viEsVce2Isn3+WJxW56DzknAkTYYgui1f5jUbJrN6Wb1ieIfM0bkdeB91ed5SAqq+hEA1jXVScoA9wBdJXJ1xsFKLZ68u1ejYIzjqobobFhAoR5chXqKwIoEaIUFnTVmcAsc0wLAyTyPnoAFYEPombO5SUDZA2c218nwLqf3b335sxh5C5IjAL0vS8om3Kz53+xSsg1+uua1i6pPIAEwHIxCrNyrozc5/50cH+Sz57KpuNmbGbupKSO2kWoBevN3r37IyZEvklhzO8jQD/TR/CtYMm6p685TN7HDBRG0h0CeMtJyAD5Jk60nrmHoJw0SGFWBoMw0dnOMnIVhWpZEBF0uQhAxaGkGHIe7aFIazNFJ7/kMgp16p+o2BDbVCiswQoOSlYo3SspfqNQuwb+DyjYuckjrZk9R1rl0SMszfzGdGTFTxdkR1Kmo8WRtVa5Iyv5/2ZHVr789LLpSAo7Vp4j6pJDR1Ru5nNediQFt1dF0Vuh+K4Xlk1F11so9J4vI+ouhKxYDv3OFLfDXvnNFYslRN241af5FWz5NFnMwJO7sRwrkq5+Iq8Q1jqKNCkFYdZIZgiTLB8ZUjOfH8x7VCC+FoRcIxNBmjCad2F5+eRbf6j4Apk9EMTkxqxbYMnunfSt3LRseaYm013J4sxN33Au1kCckGR54bJH3aWq4ugeC8Bz3d2yzADrmaQ8tHdg0DdbSN3ikHre1wTKstwgSc2KozYXAPgdLAB4wswYTGluhGgeVBhpJQhKNRkgayTLx3mzFv7/VBqG0dAI0/AKT6gosDCCH/HhFagUIdlyQ/+3VGcjBEZzd9OZ9/+hKSDFb3Z/lFp1N5314B8HY8gsftF3N5x+4TcJVnT3x69/Vdzk9j3bnxkOsCyJHi4I7zsHJuZAwchDEju/EMTS4Y4BY2I787tDqe93sasFIJaPoo4BppZzowJCkUtKAYAZnb2mm1JIsa/Wguh0o7EFpWhp+u8FAAgMFI7AopV9c8FZATQ0ghV9q1GkQEYxiqCNFSnRrnGkvSwpDmFgAQmkgIQ1sLx86TmpV1EwiBF4ZgE1F5YPlcREQYqhWWQoFEHX8FILpquve99MUnXzU+Tspj5QlUXI2gIcrBKydwf3OIItd1cOzrvZ5BdfeYVzygMmPRF2SbvqDSwQTHTgyRc8LPVYLsNpjKam2ueWYYRrFpKwOl+zqY0oB1Fx8fHuhj9i7WL5GIAC6UjnEmVT5GjsW4gP8hMUubFnO9Y2MBchSAsNqNJ+04NKpvzMgrP8LG7G1M72JRfKyD8pB5e76ixiwI4a1h78YfKXDZ+A4lKA4rappE2kAaBsnugKHzfDr/dYe3wAhp/DAlMAIvZuci9tDgHmDhJ6lh8z/0YWNVAVa4P8ZBDmA7NyBeVk2n/JjXhQxDwTW2mjVdYE0TMalqvdxWX57bt4fQJG3O/Y0wZqh7D87NCusGC1ZeR3p43Ox05sWZAtKulHuZlGl4SW1iy/vRff6jzx3zOpRdkOy8uM6mPHw0p41ubTKzlBzyiQJXUWLyPbDdaaq35mQZZPwuy12wntudnqUm5JBSADI+rONqDW4NiSkaex8J2rkEJ7kZdyEmlPXUOLmXFoltZ96XHOKw/8Vf8BI2zHff+yBywXw1dbmUTRAmY2Y62QdiHabrBnN84RflJ59c0oF5jc1szYvo+oH6jRsne038TGreDpyPn11yHLRUkzRGU0ZsaB3bIW0ttNbRM3bUVGRyrh4PoDYDmYbwGjlmDRAjZO0txNf3JB1h7j9qsPY3SqeXHtZpy1r9zdCrC8B0XL5LdJTcBor4mDN5qMDpZj7EM12m5D61BLTE5hscLgeSZr4ttjjk07cXS4g8fvAmsPpLQuBgaJt+nAbTT25ceXTIszZq49gFmnIXH9rcjaZIsAFDG8O7QFqyM7wXkWa2Lm1jni6Ni2EVl72iwXKTwHPQ37l6BFiZ2bcRYHYPKqnchCMbyLFMb0HgxALNbEv7eDEUsT/74FZ4H0LhlAkQK2zgpIuxfFwSt3EFfH1mtqhHr857w5a6IGamKdILAmZnBrVYBrzcT6TSgyZhy6cjdYADK99xUs2jdxnWCYayKR2BYDX23JxK3X4SwyIHHDNhQAIn31w8f2uzorDw8a9NA0m3NJLSyrpDCfNaLHT6eHHvV3svkWDA5ccxCMCCfsvsFk+dWPDextQHlkyLC1yzLVafOeSmU6KGWjR9XKN824Bnb8oV3JRdf9hVJvC471/8zwxNnYd9VesPwkT1Eadt1GHPF22DwuP5CsierUzDpBYM1kgFkLxoEr7wCLmFH63S+rFkD0q9N1Jm7fgIyom6/etj+xwku7ABM3b8QZsU80OOucFZxS8KrtmKAQvc1UD4MV2kUbnae6YxYrBKB6zRacFdnFGxy3b0JGUTpu+jdYkW1i5y3IKEyDXVftxVthnfOnmw8iivby6xMV1r0/cACjYC1hxze9imoLGIVrxlPu8y98MeEoZMv+cDtWSABWUDggWCIAAHB0AJ0BKvAApwA+MRSIQyIhIRWKrgggAwS1N341/YB/ABohfq/VfyA7RK9Xg/7p+0v5b/LHWv8D/dv0T/X/2j+X3d51D5bfRP/J/xn5ffML/Zeqv9K+wN+m//B/unrg+uP9wvUh/Tf8b/uP8j+//zCf6T9xvdz/Z/9L7Af89/zvrff8T2IP7d/r//Z7h38r/u//m9cf/3f8j4LP6x/tf3B/8XyN/sl/8vYA9AD0AOxo/rHoi8Ivw/5Tedv4x9R/kfyy5kD2X5D/Z/mF7X/8Tx34B35V/Qv9R+ZPvd/N+HLaP/ieo77PfY/+D/ev3g/w3pg/5Hp99gf9v+YH0Bfy3+kf6f198LH6z/vvYF/lH9W/1X+V/J36aP5z/k/5b8vPbp+W/4v/rf574CP5D/Pv9T/cv85/6/8h/////9sXrZ/YX2IP1UBP+jKZl4TunYGNmS9u+oCd0z/W0pmam+83ZRTu+lqFkAB8XAY0VLa+kjAfsRqv25bZLYiEEVrFgdupq3tcE9M5v+YtW/smc7P3HgKYJioc/Cm8l9vErulNAeNnA++mQzmjdN0rZrwkmjP/HVSYNixroXELDD3uS5I/GnSvBYLT5fxg1SpFJM9br8TW5q5yd1yndVGhHlWhzaRjNWTpnLT6hweZOQPNbWSeEXxmwKU91ZWwLU3/YJCYDyOtF1NOY7ycj/VuIHoEBT7zP+U+i0rkbiTdmwpF1Pk0pOZjy++KeQc+jtfw9X1nP6tcTFnZRIiWj6WpssLntDEvzv6dbKeUacJ/DYx6Ovxp3Lq9i7wQ/yKpLOmCszHMcqEscFvOE36Of9OCv63dqQJutHjef51UssdgPS9WpLUtFc9uCbUfLN6/dqnrLKIof9TvX4Sj11YTZ+flif64eTHaefBJbjU1Oi2I0miSqV3Y7tde8FCIyVD5RZkXPuRiZH8ar2IxwPAlSUdGYi0iLNt31ZehRb9tCqPBPe6BTeByThXmSZOUdFE3YFUrJ50SAeMmnoxoQZ2QrZCs19sm/jEEusv5WdlMMGteFcikH4YloUbJf9IPVqF1goxRXcmpQ9UBIIRxa0zs9QzfW1eH3Go1wPSdORjNzvg1p+KpyuXE1FtkvfegyG0GQmmZScBxEMbgALbkyp4f+76IcoP335yuhBJKuHoyGsXF1TK9XukuAg8MWb33XKLvT1Io9LSgEQ8hJqS0Y09BM/uAggVuOSXP8ny+l9U/3zb81K6hiULIU8uP+0iITWNhBykIZwAA++xAHtCmla0uixvfp70SUjSb55Xi3ZA/aJf/RL8Cxv73ylVV+w9/EAhB/WMTT6APM/SsGRT3tyAZQxt+MLvOPC1n2IOoZtFlM/Fz2tnb1VTKeGOpVyDmnFuRrVUgg+I4kiVw/TpOm2nJRN1qxQ7ux38a0QEsnGhhVvMoIx8sHQSFnVjGJBS1tmoZxPi3xaKNr/sJEID4y4/eJ582AsTIFfnHJXYVLP8bQ/xW+M/DvYsEkHTjc4EtLQP0g4r0K3kKKMSF/38FuUzIO9bRko82otP234rT5GOLb+ij4PqOXpYMFsMaD9aiK27QPDKk8JMKOcUm2rTb3pROwPKjbcgNnY6rsKFMfxrU380Q1lDqnT975E4OWmOzBSZirTcPi1/MXocwOrWRsY/tGrMv7lniW5FcbxfL4UjlgKvtKEehzKBzQAOZ7ZpMQd36I9XFH4Gay+zUYA4i/K8N7mgHLk+ippbq6zWJka0FKjcCsGb8iHtHebe6NMoZvIwAM4gkIUc6CSO8SbK56ffXIthxOlpoNlJtE7qpEGItZdta9YHtg5FVQYKT5RwvWCuxkGpjFi9KGpq0Wrom4UG0vBFQZmK9+Ao2z7YymKKvQWMxjeKuPqp5YRWa5QNO4sNgeFzYhufqYCrEETBrsxcnZZ01ILHzX/YTXiB3NiE7F++tOx8NgJ01SlCn/5ZBLX6H+K6wtBCdfknGdHGKul5EZCXkvpO707RzFtWU2ROlonWRArNukO1LotxHnds+WgqT8Mwx3SGfZ4DkW8iYWhANLB5imKR/UaLvmJp/X59zHxJHSrs4j6FcY3c2QUi5WonWOMB8f5kRw7iBt/gl8hyv3U6aY1B/1JsIGy5ZjpVfHpNVIzwFQ/vc2F5PS71FdZ+u381MLoEY0BVNwqqqgBL1DNtqfsmzc+hCRnCxneo67jHOE94LIt40F+1ZgUglHgRveC8+uvPS0PoPvCC5ODp23ydyOURHbA1m1f1IX/X1s+jIhDllZWX+CA8N58Y2vIIBvSFTJteEpv8vbBAJr+TOTRb1uPTBA/42jKdJshzzWUBQquUUC+BUCO1ZwrPoWG/gs/TGIt4tECQlgLVcU+8RYJTxXXLBAYwQon6ZxWrAnhV2hSp1jPqQuJn6HDJYzpHPExWmuEP469OCT9KukOEj7pia9cdkluSmFV6j8dx0xT7ZZZT/LK+0I76O7tz7vxcDveG2qxva3pP/FydV9DYKU4ZD4yXdk2e/n56N6KLe6XZt0egGgGw2zGKTcEPJrDDnhERgq8hjHyN7AO+C03Jbq1c5LgFZuctjQdJ01gYpZnX18nt0YmDZ+O0kkewLnkv0a8szk9dC7xjBQlmuuhLPrqwBrJ18ouTrTMTAzYgutWhwG+gg2+5dKPpwrcvBzOibIT2WHlP+vE2dWdhFz7Gu1P3YHTlWq9ickEuCOS8beIioF9nWexDKsd4SEu6wkb7Yp+8Npe4Xhb67+Qy8J2n1ikrcIwhl36pr4p5uxXfMeq267oP6z7ZYvA9aOfqjUJ4tazV4tHtBxx7IpfR9hB7Ui2YIrGTihV0WumI9wCoOQ4lZvUtBfp91EXgOlxtX8L5cOaDeMhATicD9152RZ7wgoY8lyhaph85tFiVI7OGwty4Tjz4YdgDFGEJRPozy2RnN9Z6HYFxWphQnqYgGCkhK0zKMBQVRLPhlv4MkgdZyE2GUEyoEo6YHMy+cR1uuueNhqbknJ0BsE68a6ueVoAL59iy02ew1PyGRy+WydB+2f10LYm4ifoOZnbCHslLD0VLclKtHzvxJdhV8JDZRCumCMrGOi6N3ViKBuFDxIyugV7LFxQuWu/gxzzaHz9G+nKkBX8nP9ZmwhnjRS2EIR8kvjjWCq4MXGAd9x4qGstqG/q/QdNwsQ9QgcQ4MJ36fqKlVPDw1tYniEnja89YJVUlyDvQYUXR9tSJ2ZjJspsyf9ZtRomhMNqvBykHvA27mibBH30E410PKHPxQ0OGNcE6EfrNi8wRHpplbH68yjoYQvme+GFELn/zNfD0EdFaiqwbQIkwiuvJRQwxHFE70cRD0f4y4p2AOcmva6fwFNbplriS0NbGTg5jTAeEeimWTL+YZd6JKCqk8gZO1FjkpVdAotbzTsGrwekukquvQNDh5rtOnjfa/+fBua/ZGtB+Qgu1TwvNULrT5ZpgAmszQGOEmCleYWP86BgyxK7NLN3DaUclTW52VJi7FtiwSxZknff/foaFivNnAw8beDfqt2PvIeTOTiG9ZnKJlhjglq4/IwyGtOKiznDRR6dvsZwYRovgsPLFbYdJgSDSrcDhKGGf6ZldF4Kwk5S7aQI33dvdB+ZEexNSW9lZ6VtkN8M225chko/uk/uoKjbZtVQgm8ao5ncR7BMFD0QWpLvJmr41kQs/mAo+fcPgJZtIkV1ncE2/ZEktkrR33kUK9uvLh3ww8OsqjAWGYbib0d20JqVJV+Sz7QHUcGR89U0lAvMcAXg+Apjt1Ye8vOs/lh5gIlGYqiNlXzXoYy4H2IDaQmGkjKpzujvRwaeRy3lPFJpOI15j37bEkhU3KOqiLFfSBebjTiKFRfsNRNndAyLFMaQIKBvhy4GtSG45tGOLwHOo7DIxtVVF6gTSo5jub+D+ZOzX1HHJtiKmlP5jb+wx5rGj8Pz+Arl9Z6UGjeIcUOwwUIiHfBYScLlKGS2rdw73W3+B0vAuLCHpOi9MMvQ2vbqFsGgbIgsoLnMDktLsBj3ClnOk+Z/cQhHl/kE2OzM3serv4G9G8ayDfC/pCD3LIpajIXX8pr+CrtRvOOFY2Vf7apN9L134uG57Ok17JEy/jDVpIvC1dDfcWzp2e0wiwk1HEuyDOsw3u8feSNAbxM8mdS/q8yNY2GnE5fnrzPKSzH51co6zoXMuN9pXA0E/g+ya5GnYq6uAPK0N9c1a7uX9jpweeOMC1vZZGQwQGiZhAy8DFsAmZ33FGvkQiuj/ZaST7nrwEAJ2QBHNL3IrooaRprRbxgdXb6sOLE0y1rjuWnRdnf4chKdrJv1K0Kh1/jYmGMzQLaHhLPLlMmFmF03Y4P72vcBNsfCpDSZ6r8rHGXkglmLtPGqVb/wAaSLLxssU0lKl6fs/oab0Dg57QLXBdRHvowlS0bih1Y5Xsr8eu08dHvm4cukBhAZhNvyRjtVsf15ZhsG1KFbT/S/RGex7noWADWQPjr9FRDfV6JtUGH9jx8ripS9N+D5U3Ivooyxm/xj4lAhCJfBddsG7LL5xmjVjm5INoN1vRx/X6ES1bpKLy233hdqSDqNticbknsSRjOgqNIqUAkqWeNYnJn8sb9DxvkncxtreDaQTxH/4A83G2BuoiGqc9hoJxaJNn6CH3pugFyrQ7IE7S6md2O3z0W13i9Q3CTaYwvtKrrNbfM2PrWGttPJhCh2RNNLWm3IZagaJgmGApaTUcLZlTgvHsJi05RpcOPg6xwGN+kEt8V+Hm7WYy6GgJJduuzANV/yjFqLH1N5BJNCfGFE5OKyQWMxvVQUlGV8uoScZb1EM5thF1MBPQwEEQsAUZ+mTyYdI3fzhMHsjkYud2UCirVFkDSSACicw6W49i+7K7LZJVSAQ/XfBm0eVFP70tSzKKL1qY2Ma5Ha6Kf13r8nf+EphGmCtfUCoOuyiNs7RAOWEKNKWqHWlHvuOfAPC3HdxlUZma+jlgJwrz5Sx4sriLVrfv3JaQNY84hcSTkQw6F9EDPjby4x9eWA/7+QJ24d9gr0OBWdrp08eIWmWgi1qv/5qD7nKENh3cH7Df/LKAvnMubs1vRBN3azcBilLf0AGYfOWlm3H4+CZfKcjFOCv1f6zOnwh47DcMNheC5CGJ7sCZNPqJuRWJkx5OdfW38HuUAx+Sz3yH8kisCm3AS5qTvCzVIqRGHahUgSGzQ0pvecfvIyxEWeAsgqfAt5fqmeyeQnDPNbK+ypeknKa1w4h3fiAVQKMxUDhbEWvb/EhuzYFOo/HrM9V9BSMNo+MCl+dwtmsP6U3WBf7Sq8SpyluVa3cbbu7sJYE9xr1IiwE5oYlBvYIgDjfNiUhly45x4zlS/M152kbZ7S+8//4marA3dYWpv2JbAIsS+6+xCBlaCuG9VyAlOlrrr4EgBULmfPQmbnpCaEXdwZ9QarLF5lmrz4UB3OhEisYSyNPxwjOSq96zciaaiGn8lESG3RgvmuN03ubbO4BzZM/ADrByxvs8H3xR1kHgwldPKOmjQU5+wEjzotmbTbXKPOgALJQDjTgqHUNuTUfMAzJGqFmo/M7OHtrtu/D+9fneLyPfl95P1Vc2eJKvIuTVSeQ8GpXZLBEaHyuyt+ZAH7fpNJEUN1yS/NwxL30p84lp1xYVB6bPXlE05P2zkYktd5eRCXq/GYQ5hTKUv17T7rJQqe8rxwM/K6pXTeTBb+Gv8Pr7Vgv7Ln+3+tdUp7epvIXl/9+xrSYICNFFBasSXCjWmyhDh/fY0Opn4HXXQi7M7N60hL03GtdGSkc0tfyToSxLpq958MrJK73qBctFZexaUoNqx4MnIBB6YMdCp/AkX4nwDhp9d0NOoqzNbeULQIhwN2GpG4EC+17Wf4tuAE3uUwBDBvAAAB8uYUNXAF3BXX0TEgVM5JJFUnmnD51db/bMuClLLX1Djzz4BS8PMoU8Xw7xuYh5AvMUUZEZ6yEINaZ2eV7jEoDgpHxradiNle5rUx4XjeeMr26bmnAeZHhfpH9YB2V18AMVROYXJ6Qd4MmP/4bHL8hpF3pxTcn6Lzb4kDVIAQn7Ux8Oj31KBU0da+7+AL7aehaGwgcmrJP/1CP/n9r/4lof8MJ/5ejOwIj16BF5l1S8zC0yANP30ma9v6T75mr99PO72Jqwac7ZN6FdVBsInXntFDh6sZC+Xn1prAbHygCE307+RHq3uSVe1r+VkhmQaMkYTe/QI3OPVcXo96Jb69TxxEfqMEZP++Bx6HTsr6Ruz+2AvBlQXmc9YxOgYm91yu8HEUoYdVkFB1zG2qV/bVDJw9n5zN9D0jW50cy2iiVsnxBg/4quLH0J6YLkYkoE/rQHq1y4kVXV6C6ryGoTI7nwVxKGE4vtux6ONyCM3SUXRZOlrQ/h1zKMt9msMK7AU54zULq7d/lz+reR+qRHVDtGQNnaIFSjGw5w7uIpXVpgWzvEYCfp99aSOi9Kn8qLA/iApSWikTzbD8JIHtROuBDXMZ9+kLqPN8EAbHmCG7f3H8QrJvvGL/oDgRALblJZzf/BsUNvY4BAEW9VavCC/t/hcrMhprV9IOUkvzE91+TkBer1Y8hckH/6B8AbKk+nIAA7YX9SngpYRzYj8mGK2Iy0f9+PHI8i7dgE97Yeg4lpIvsKtS64wldIIa0KQnRxWR4hzY/LH7MJKJwG7xB9YAZyXjymYtr1tEDkiMpWMg1mznCf810DCJ78fA8jExPEsMg++/swn6G1pw41KmBw/fy0OzM0HML/XCaWKysJefnDO+X6OuWiigHiZ2YX+DQNMRm+LxFWw+B2Wm6fag5yuOoLHRCpWvDzOXzcJVvwAMvaeBI7UaDgHxxSweN1E0nJVJaXdc4RSLtwsZSnevlToIUa4AbzzsUJy20xnrmsMCEoGGMmRQ3t7pAB6WC7DjyEzEYzRMMcSdU5StvPueE8hCUnetz7GsoxNaQ1wwirzXyGJwwo03UUZOlQ8be7ZaTZ11P3rn91d/kGAnw1+Mcah48eil6ne35mro7yJVs2sshp1S+q0zOOW3GLhLnHvtvgNC7yGT/T2Piu2l/BHj6I9zaZEQd83WlkGNS+PI41piW6XVmEVHLxBqDc2ZvZR9Hfn1n18h1zoGGMgAAFZORiaQ/SUMZKg8LRQHh2lYy1dDGbBnpneW94Fdr+JysvVr+p2rmW6OBcX+w36gmm3/2bZ3lkWg6sOKBxJDMsUjtqDWpnSo6j0ipShz6rIGZj0I64L3dMF9X5jc6Ktj5PVoYRwQcL7sO/2Sym/p5zqncqfqL5O/y9H47Up2TCEIf7eRBtb8VDrpxKk44/OxK5c2+I8Wz2uN3c7E0H5QUVRF1H7Ccw0tu0hGWuOdKVZheqsNpHSRFbdnsNODrx3QjkmCj1PIPhgxTaDnAICeKQK9PP/0o0PQXFWXTDSwQJXDU8m99KM+AoNp65uqZD5MdH50Qtka36Jg5AmySdsc0XuYdkpCpAMBQy5hAH6pHCoh5gakJ1o/h1UtEYXUo9DEOtvlpOTXknUK8rF4NhzIDF3wh3fLBP3iIYNgFim017hM/BjMpqXfy1xxN/9kNC3nm91oj19rc/T/KTOiySO/9lLATGNZqdzdr44NFaOLhR43bjps00XsyjvcjqdA1M8Y1K8zsjFzWl3F/dX+7AKeKciclXx6+H4Xd8BBs0s5UdSfEQKZC8eY0joAmCjvNZRFn6z+CR7UrAv3CfZV7FpDJAqw4rZdtMN5s7QMuv9Budkcok6fqxFbLgR56jdWhA5inlEMe3ABFCVhMpWq+Lzb7jMwbge/WZpRfXEzvYAg7qn4tPjAio6lw1ExO25Av7FW5+pWKsjRuYa7SVZt5BXX64uzYiEPuaFIJQXQcDbvxGC0k9UQTC0mfdp17JBZo/K3rIoHGXBD7p9rvfa/DlMsJ+uy3oAIqGKq/Za+oSkmCY9gX8ZvmJD0I1QbB4fkmcQp/p24BS5ND4StXaNHtaplF3J/wVOdMNmxly/59H9du+CFuUa3Rklygm6XISwtAdk+gaS/9m6CCnX5dKVBb+qS0GmFd77DUkD1H7KQI/c02Bu/8gS89uo/bA8+MVM3cQU9EtEYyUSp9p9TyQgIDYxLwhOKRGw747N8sXRsy8CIzvfBgCmMCoFfdp1BSUoN/Kzpi7Ix1a0oXv2Tc1YJcEjrb/WVgomv/sgvy00/+fqZHNt55DE/seGdlQYNZsUyH9+zJL4//054kV1SdFzjQLj2yPsGeQjAyyE1p5J2Cko3duL7mLmpRcDac261nBHTDJPKsIDw5651MrOO72GbGXptTj1N4J8pXsKcX04Iee4ytRlcypbRM4goKtqjwo/jTwLyvbOcIoyTCpAwKtNNk785zQXBNuc54AQWQd8c4JWPSj5x0bGW8IuKS3UDFRi8XK76GRg4eh9ZUKlHzGekm2TCDJ3jeG5p/yg2COV3W5TtgOKJdnRq/Cj+NSpMwvtX+vZ8PfPdMs6meifUe0YAx+zgSI++wA9SSgw2GevErNWkfboYKB0JRcYeOFwQoQFGLKl3CISaswXYxtgcJ9i7A6W12AO9B3iQGFL1JTXL+IZWQEGsjzZGiWePNFnffleDpdxf8kJiGV2xYL90CBhYhi7tD9YzmJlsOinKFEtHxWW4uDn8mEIpeljimC+rsiN3XGGl/t5ndgos74h+mdrywU28+bI8gTpcXov4xaNHpbfkvZ3/5+KxbBvfdw7vRKSUVyVYmYAsPRMwLl1vrEOGoW9yt5CQS2l1lSu6Z7LL8RqMnlpachsZhhgiRRDT9e0ZpILCQ4n8iGNy+0SjVpQcF3lJWbzffv8vxPL7hB9CAv3b2NyZwYXmyUcORH3uyY/yKa0P78SOf2Wrf6G0lUYOgCtRYD7RE2UvbLP5RCw52MdLCQAL+C7j74uDjC+W8KNd57Kj9Zz8VdUEJ0ZJsCmo4QKO+wV0y49sH76uehSezq6VgYV4gOfJSEWR8+GA6v/l8YJN4lAQI+2+2hd6uMrU/kTkCbPyS4YT5PwVQFt5v0HqJ6/7pNNkWaAUMVqryVx9SchHyROGKj1NFl/EN2qTreeGcE8FX3trmulsCtAsm8unzRyr3n9vpvdAHM2vnY1N0FujBFkksVtR2QPHw3LQDtyyVZEL8H0zySsZYTL7N4219wKubxRtw2y9dW++wUTRdKhP406ibYYh2APBsNKEyUMHK5jWwMSld+l2oYY//WFowRBd3vbW1ggDkTZTBRYWdxBK7Ff6iTyPmuV33/a30vifMVdZ2TclUkNMzAANKPtF0ItvHWFGzF8jSIXQ2s8T3GU5u6FOQibrwdoQxMRlNCu3YdsmKBtmzcciWEmTy+EPdbNoqplbtMPH2q8Zp5rvvccPoEuwmLMLdsswhwT+cP6edS7Rn3kakXdq111qOSKKvP7fGzATgwfQIx0tFfN4q3hyjH2xbb5dzjFbOXqbLMW8IIXcvDqXWuFwgttKwZlchk3vKg5xB0hedcar5y/+6QECvzF01y8G4etBAxy8AV1/hCVqltYTpHTQwgjYVS+hxXu8biz9YzXZMxfeQWG9QgROe0SF9vt4kJfHEhQ6x0vHPmSy9eb4dKVkQehQJOKGv8hl6gy652ttrbyrHc2+IOOsZ0loBr33KoC0kKNfHw5lS+1+dZBb3e93C/EqduXGThCcR5TeYS6Gu4bIieY7QXV3xRQXt+LvTxF2J8BneEvEnN3n9Ywuk+AyiYStcPnM/5qpMk/L4mmY1tU9ZOO3WGq8tZDNdxEJRHAz3HF5MsEyTzHhDxLYVRnWz17hHLGLHCr4Gp8u1iZ9/SX2xcSh9ks+bvCtcuuFax40p4HSw7NOEqCvOYt2VI8VxFl/aTQoPXiDYL+dX7qY0k2RhtUP7HqVLL6oYcvG3zvKbDYBA3C6WRKFxPN4eQGw7UjLSRGUXE3ShsVXEYaDcVcnjp3rSlQpmpLI0LIOUgiYwhseEJvWEo3ncJoElLqlNmkXOPhqtca0RwSxhxQ+ldWh50b9JDilseano4or0B1DW2myFBTfBxuHwxMC0JEdHqfWsmUFQ3PAlGQiNUhjRZR//NPO/vGGqO7puELHaZnuC8Uh0D7IcYzTu2XgR4wRq3DCHbqskn5nBXpB+AIij/VoFMDlXkinRwuwwebndCWa1+nqyTmorX2d+Oo2hE2Nzm1QTsZRxOyGW60NdND/ISPtH62SAy2W0kNHQdDL/LkJ1GuhasSc5UgdM9ntIp0MMDxVQQnSGf1utiCU+r0OLLb8H7G9b9osQnkSHQPr05Exgm2u0P74rcahIZUgmWZPnwOdyF9ZFV7AzYD6encnZOpcruTBU8L+FeRzaOLoXmDSj9N82xMrCVxZVwwHzcXXtdaTXgR3fYozPgK7SHt8XEA0sR/oCL6Csg8+0iTfC5yYc5zddInUZH51k/1vAOPXJsf+/9RO0PfOy+qPGM/gvgiL6DM2Y6/CDAD151VNsVxW+C0vFD6KZgF6LIcgjdofZ5Yu/v79DorJIjMs5GDvzAFg7xsD2kTOViBEhP6KMuIeYVGsQWJcmP+jzfIUiuYYLIA2QS6ANhchqV00N8Cq7QBswnGUox/9A4B7hLgmaOkCpB73dhwzDqQZzIeGoqb8cD1ZSD+EklA2GPcGJ2a2WfxgImXNhrjYIQ6ezDbkipdmzNkOI0qnGEPCOZrvmy4S0MDZ6+RcN70adZjUww7rifAJWivFdC+2pMzN/Vr7oliWdTVlDL9Qbo200FSmq7Zp9ifWu7aZu7/HF2X6KUp97VHNBHxXfaf7b4aX4i3xqKXKgnoDig87oBAYnddPkP/Jp3oKuRvRvrWKhZ6ponMWYMhrpJGwt2Uln2v9WYE3o/hlYeoS5MT0kjUmExA8tIwcqDoc1XOmBxENyliB+VEz9g3MRgfoBnJOG4xtTm1YclZ3jDY7eJVzLA8kyXpS3H9SNevquxo84KYEsYhMjfA+jJ9tTQqsI8Ofof+24SNV57E7QDXuBt3fi0T3zherkTDPhmYlAMHtrbyX47R63QA5AyoZ8gCRF7cC1uYpilP2p/ehpUxctzoqVK4dBjgPBE2OCzHcas4xAhzvmOyI7epLwOFbuSR2xSXoLi3NgbAfEjVAPbz0ikiVFcRe24ILKOWaoWK9gOQGQjLD+/anKin8F/zitZrDs4VzsyBKqwYlJHG48l7ZoPH1YO5uEwkAU0j4QcUIlrIqVhdOxRsIWdA7CfuZBeyzakrSh/xiXu4eY4MsAk2wUo6uAu5TEiJ6pZd072rv0g4kMaIPn8l2vYb0K8pmQrDJWAZ3RfwESbu5iLvoH68pW2jttdZ9rsyzMqNAayRUSdiFTfHoFTXAYoPLMW1YLi+QVZGhe6+zFBmN7M5ro79TVv35efReUYFEmZti5SjUOU1TAEk/9XS3z6ulLm9EyN72Q4h1Fkn+ELwQUzZVgHUU2ReETwVPIbSJyVanSJ1UXsZ2zFdNEJgDaKlakqk9FdgqaQzPGBj2FC8YBVTOF5/fEK0yz8AmCLogEXXWvqcY5DfG3wKypCaZhljxDN3vxe9XFs62ijDmrkDRZrTiJ1hXkfArw3yhiGil8F3zJhf6U4O8bX9aEr2ltjGGZ3YvNYFY0fZtkFu9MXBN3Dz6lyO4ruDRSlB230JdYOKzQ5MVzZxOb0AACpyPpSq3fUskiVOAJFHXS2F6gocZLaj/l9Mgt9GdfF7RTeFTrFLeYfDC7POpviRpMgddqZGbsG2c1vrzKRFMj4soBteP1OqxKAlrwom7gEA2EngAAAAAAAAAAA';
  const CSS = `
    :host { all: initial; }
    * { box-sizing: border-box; font-family: system-ui, -apple-system, "Segoe UI", Roboto, sans-serif; }
    .panel { width: 360px; background: #fff; color: #17140a; border: 1px solid #e3dcc6; border-radius: 14px;
      box-shadow: 0 14px 38px rgba(0,0,0,.28); font-size: 13px; overflow: hidden; }
    .head { position: relative; display: flex; align-items: center; gap: 10px; padding: 12px 10px 11px 14px; color: #fff; cursor: move; user-select: none;
      background: #0d0d0d radial-gradient(120% 160% at 0% 0%, #2b261b 0%, #0d0d0d 62%); }
    .head:before { content: ""; position: absolute; left: 0; right: 0; top: 0; height: 3px; background: linear-gradient(90deg, #8a6508, #f2c94c 50%, #8a6508); }
    .logo { flex: none; width: 52px; height: 36px; background: url(${LOGO}) center / contain no-repeat; }
    .ttl { flex: 1; min-width: 0; }
    .brand { font-weight: 800; font-size: 13.5px; letter-spacing: .14em; text-transform: uppercase; color: #f2c94c; line-height: 1.2; }
    .sub { font-size: 11px; color: #b9ab84; margin-top: 1px; }
    .badge { background: rgba(242,201,76,.16); border: 1px solid rgba(242,201,76,.5); color: #ffe9a8; border-radius: 999px; padding: 2px 9px; font-size: 12px; font-variant-numeric: tabular-nums; white-space: nowrap; }
    .icon { all: unset; cursor: pointer; width: 24px; height: 24px; display: grid; place-items: center; border-radius: 6px; font-size: 14px; color: #e8dfc4; }
    .icon:hover { background: rgba(255,255,255,.15); }
    .body { padding: 12px 14px 14px; display: grid; gap: 10px; }
    .body.min { display: none; }
    .row { display: flex; gap: 10px; }
    .field { display: grid; gap: 4px; flex: 1; font-size: 12px; color: #5d5640; }
    input[type=number], input[type=text] { width: 100%; padding: 6px 8px; border: 1px solid #d3ccb6; border-radius: 7px; font-size: 13px; color: #17140a; background: #fff; }
    input:focus-visible, button:focus-visible, textarea:focus-visible, .btn:focus-within { outline: 2px solid #d9a406; outline-offset: 1px; }
    .chk { display: flex; align-items: flex-start; gap: 8px; font-size: 12.5px; line-height: 1.35; cursor: pointer; }
    .chk input { margin: 2px 0 0; accent-color: #d9a406; }
    .chk small { color: #7a7360; display: block; }
    .btns { display: flex; gap: 8px; }
    .btn { all: unset; box-sizing: border-box; display: inline-block; cursor: pointer; text-align: center; padding: 8px 12px; border-radius: 8px; font-weight: 700; font-size: 13px;
      border: 1px solid #d9a406; background: #fff; color: #7a5900; flex: 1; font-family: system-ui, -apple-system, "Segoe UI", Roboto, sans-serif; }
    .btn:hover { background: #fbf7ec; }
    .btn.primary { background: linear-gradient(#f5d261, #d9a406); border-color: #b8860b; color: #1a1405; flex: 2; }
    .btn.primary:hover { background: linear-gradient(#f8dc7a, #e3ae0a); }
    .btn[disabled], .btn.dis { opacity: .45; cursor: not-allowed; }
    .btn.danger { color: #b42318; border-color: #e8bcb7; }
    .btn.sm { flex: none; padding: 4px 10px; font-size: 12px; }
    .btn.file input { display: none; }
    .status { min-height: 18px; font-size: 12px; color: #5d5640; line-height: 1.4; }
    .status.ok { color: #1e8a5e; } .status.warn { color: #9a5b00; } .status.err { color: #b42318; }
    .bar { height: 4px; background: #efe9d6; border-radius: 4px; overflow: hidden; }
    .bar > div { height: 100%; width: 0; background: #d9a406; transition: width .25s; }
    .list { max-height: 300px; overflow: auto; border: 1px solid #ece6d2; border-radius: 8px; background: #fffdf7; }
    .item { padding: 7px 10px; border-bottom: 1px solid #f0ead7; }
    .item:last-child { border-bottom: 0; }
    .item:hover { background: #fbf7ec; }
    .nm { font-weight: 600; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; cursor: pointer; }
    .nm:hover { text-decoration: underline; }
    .meta { font-size: 11.5px; color: #6a6455; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
    .meta .nophone { color: #9a5b00; } .meta .hot { color: #1e8a5e; font-weight: 600; }
    .empty { padding: 18px 12px; text-align: center; color: #7a7360; font-size: 12.5px; line-height: 1.5; }
    .foot { display: flex; gap: 8px; }
    .foot .btn { font-size: 12px; padding: 7px 8px; }
    .acts { display: flex; flex-wrap: wrap; gap: 5px; margin-top: 6px; }
    .acts a { font-size: 11.5px; font-weight: 600; padding: 3px 10px; border-radius: 99px; border: 1px solid #e3d8b0; background: #fff; color: #7a5900; text-decoration: none; }
    .acts a:hover { background: #fbf7ec; }
    .acts a:focus-visible { outline: 2px solid #d9a406; outline-offset: 1px; }
    .acts .off { font-size: 11.5px; padding: 3px 10px; border-radius: 99px; border: 1px dashed #ddd6c0; color: #a8a18c; }
    .done { font-size: 11px; color: #1e8a5e; margin-top: 3px; }
    details.tpl { border-top: 1px solid #ece6d2; padding-top: 8px; }
    details.tpl summary { cursor: pointer; font-size: 12.5px; font-weight: 600; }
    .tpl .col { display: grid; gap: 8px; margin-top: 8px; }
    .tpl textarea { min-height: 64px; font: 12px system-ui, sans-serif; }
    .tpl .hint { color: #7a7360; font-size: 11.5px; line-height: 1.4; }
    textarea { width: 100%; min-height: 76px; padding: 8px; border: 1px solid #d3ccb6; border-radius: 7px; font: 12px ui-monospace, Consolas, monospace; resize: vertical; color: #17140a; background: #fff; }
    textarea[disabled] { background: #f7f4ea; opacity: .7; }
    .licline { display: flex; align-items: center; justify-content: space-between; gap: 8px; font-size: 11.5px; color: #7a5900; background: #fbf7ec; border: 1px solid #efe3b8; border-radius: 8px; padding: 5px 9px; }
    .lnk { all: unset; cursor: pointer; color: #7a5900; text-decoration: underline; font-size: 11.5px; white-space: nowrap; }
    .state { display: flex; gap: 10px; align-items: flex-start; padding: 10px 12px; border-radius: 10px; background: #fff8e8; border: 1px solid #f1d9a0; }
    .state.err { background: #fdf2f1; border-color: #f0c4be; } .state.info { background: #fbf7ec; border-color: #efe3b8; }
    .sicon { font-size: 20px; line-height: 1.2; }
    .state b { display: block; font-size: 13.5px; color: #17140a; }
    .state p { margin: 2px 0 0; font-size: 12px; color: #5d5640; line-height: 1.45; }
    .acct { display: flex; align-items: center; justify-content: space-between; gap: 10px; padding: 8px 10px; border: 1px solid #ece6d2; border-radius: 10px; background: #fffdf7; }
    .acct small { display: block; color: #7a7360; font-size: 11px; } .acct b { font-size: 12.5px; word-break: break-all; }
    .sec { display: grid; gap: 8px; padding: 10px; border: 1px solid #ece6d2; border-radius: 10px; }
    .sech { font-size: 11px; font-weight: 800; letter-spacing: .08em; text-transform: uppercase; color: #7a5900; }
    .lock label { display: grid; gap: 4px; font-size: 12px; font-weight: 600; color: #17140a; }
    .lock label.btn { display: inline-block; font-weight: 700; color: #7a5900; }
    .lock label small { font-weight: 400; color: #7a7360; line-height: 1.4; }
    .ownerline { font-size: 11.5px; color: #7a7360; }
    [hidden] { display: none !important; }
  `;

  const HTML = `
    <style>${CSS}</style>
    <div class="panel">
      <div class="head" id="drag">
        <span class="logo" role="img" aria-label="Haseeb Crafts"></span>
        <div class="ttl"><div class="brand">Maps Lead Finder</div><div class="sub">by Haseeb Crafts</div></div>
        <div class="badge" id="badge">0</div>
        <button class="icon" id="min" title="Minimize">–</button>
        <button class="icon" id="hide" title="Hide (bring it back from the toolbar icon)">✕</button>
      </div>
      <div class="body" id="body">
        <div class="licline"><span id="licText"></span><button class="lnk" id="deact" title="Remove the license from this browser">Deactivate</button></div>
        <div class="row">
          <label class="field">Max leads<input type="number" id="max" min="1" max="500"></label>
          <label class="field">Country code<input type="text" id="cc" maxlength="4" placeholder="92"></label>
        </div>
        <label class="chk"><input type="checkbox" id="deep"><span>Also get phone and website<small>Opens every listing, so it is slower but the data is complete.</small></span></label>
        <label class="chk"><input type="checkbox" id="emails"><span>Also find emails from websites<small>Only for leads that have a website. Checks the homepage and contact page.</small></span></label>
        <div class="row">
          <label class="chk"><input type="checkbox" id="onlyPhone"><span>Only with phone</span></label>
          <label class="chk"><input type="checkbox" id="onlyEmail"><span>Only with email</span></label>
        </div>
        <label class="chk"><input type="checkbox" id="noWebsite"><span>No website (hot leads)</span></label>
        <label class="chk"><input type="checkbox" id="hideContacted"><span>Hide leads I already contacted</span></label>
        <div class="btns">
          <button class="btn primary" id="start">Start</button>
          <button class="btn" id="stop" disabled>Stop</button>
        </div>
        <button class="btn" id="findemail">Find emails for saved leads</button>
        <div class="status" id="status">Search on Maps (e.g. "dentist in Rawalpindi"), then press Start.</div>
        <div class="bar"><div id="bar"></div></div>
        <div class="list" id="list"></div>
        <details class="tpl">
          <summary>Message templates (WhatsApp, SMS, Gmail)</summary>
          <div class="col">
            <label class="field">Your name or business ({sender})<input type="text" id="sender" maxlength="60" placeholder="e.g. Haseeb Crafts"></label>
            <label class="field">WhatsApp and SMS message<textarea id="msgWa" maxlength="800" spellcheck="false"></textarea></label>
            <label class="field">Email subject<input type="text" id="emailSubject" maxlength="150"></label>
            <label class="field">Email body<textarea id="emailBody" maxlength="1500" spellcheck="false"></textarea></label>
            <div class="hint">Use {name}, {category} and {sender}. The WhatsApp, Gmail, SMS and Call buttons on each lead open the app with this text filled in. You press send yourself, one lead at a time.</div>
            <button class="btn" id="tplReset">Reset templates</button>
          </div>
        </details>
        <div class="foot">
          <button class="btn" id="csv">Export CSV</button>
          <button class="btn" id="copy">Phones</button>
          <button class="btn" id="copyem">Emails</button>
          <button class="btn danger" id="clear">Clear</button>
        </div>
      </div>
    </div>`;

  let host, root, els = {};

  function buildPanel() {
    host = document.createElement('div');
    host.id = 'maps-lead-finder-host';
    host.style.cssText = 'position:fixed;top:72px;right:16px;z-index:2147483647;';
    root = host.attachShadow({ mode: 'open' });
    root.innerHTML = HTML;
    document.documentElement.appendChild(host);
    for (const id of ['badge', 'min', 'hide', 'body', 'max', 'cc', 'deep', 'emails', 'onlyPhone', 'onlyEmail', 'noWebsite', 'hideContacted', 'licText', 'deact', 'sender', 'msgWa', 'emailSubject', 'emailBody', 'tplReset', 'findemail', 'copyem', 'start', 'stop', 'status', 'bar', 'list', 'csv', 'copy', 'clear', 'drag']) {
      els[id] = root.getElementById(id);
    }

    els.max.value = settings.max;
    els.cc.value = settings.cc;
    els.deep.checked = settings.deep;
    els.emails.checked = settings.emails;
    els.onlyEmail.checked = settings.onlyEmail;
    els.onlyPhone.checked = settings.onlyPhone;
    els.noWebsite.checked = settings.noWebsite;
    els.hideContacted.checked = settings.hideContacted;
    for (const id of ['sender', 'msgWa', 'emailSubject', 'emailBody']) els[id].value = settings[id] || '';

    els.start.onclick = startRun;
    els.findemail.onclick = runEmailsOnly;
    els.stop.onclick = () => { run.stop = true; setStatus('Stopping…', 'warn'); };
    els.min.onclick = () => els.body.classList.toggle('min');
    els.hide.onclick = () => { host.style.display = 'none'; };
    for (const id of ['onlyPhone', 'onlyEmail', 'noWebsite', 'hideContacted', 'cc', 'sender', 'msgWa', 'emailSubject', 'emailBody']) els[id].onchange = () => { readInputs(); render(); };
    els.tplReset.onclick = () => {
      for (const id of ['msgWa', 'emailSubject', 'emailBody']) { settings[id] = LF.DEFAULTS[id]; els[id].value = LF.DEFAULTS[id]; }
      saveSettings(); render(); setStatus('Message templates reset.', 'ok');
    };
    els.max.onchange = els.deep.onchange = els.emails.onchange = readInputs;

    els.csv.onclick = async () => {
      if (!(await ensureAccess())) return;
      const list = visible();
      if (!list.length) return setStatus('No leads to export (check your filters).', 'warn');
      LF.download(list, settings);
      setStatus(`${list.length} leads exported to CSV.`, 'ok');
    };
    els.copy.onclick = async () => {
      if (!(await ensureAccess())) return;
      const nums = [...new Set(visible().map(l => l.phone).filter(Boolean))];
      if (!nums.length) return setStatus('No phone numbers to copy.', 'warn');
      const txt = nums.join('\n');
      try { await navigator.clipboard.writeText(txt); }
      catch (e) {
        const ta = document.createElement('textarea'); ta.value = txt; document.body.appendChild(ta); ta.select();
        document.execCommand('copy'); ta.remove();
      }
      setStatus(`${nums.length} phone numbers copied.`, 'ok');
    };
    els.copyem.onclick = async () => {
      const em = [...new Set(visible().flatMap(l => (l.email || '').split('; ')).filter(Boolean))];
      if (!em.length) return setStatus('No emails to copy.', 'warn');
      const txt = em.join('\n');
      try { await navigator.clipboard.writeText(txt); }
      catch (e) {
        const ta = document.createElement('textarea'); ta.value = txt; document.body.appendChild(ta); ta.select();
        document.execCommand('copy'); ta.remove();
      }
      setStatus(`${em.length} emails copied.`, 'ok');
    };
    els.clear.onclick = () => {
      if (run.active) return setStatus('Stop the run first, then Clear.', 'warn');
      if (!Object.keys(leads).length) return;
      if (!confirm('Delete all saved leads?')) return;
      leads = {}; saveSoon(); render(); setStatus('All leads cleared.');
    };

    // drag
    let drag = null;
    els.drag.addEventListener('pointerdown', e => {
      if (e.target.closest('button')) return;
      const r = host.getBoundingClientRect();
      drag = { dx: e.clientX - r.left, dy: e.clientY - r.top };
      els.drag.setPointerCapture(e.pointerId);
    });
    els.drag.addEventListener('pointermove', e => {
      if (!drag) return;
      const x = Math.min(Math.max(0, e.clientX - drag.dx), window.innerWidth - 80);
      const y = Math.min(Math.max(0, e.clientY - drag.dy), window.innerHeight - 40);
      host.style.left = x + 'px'; host.style.top = y + 'px'; host.style.right = 'auto';
    });
    els.drag.addEventListener('pointerup', () => { drag = null; });
  }

  function readInputs() {
    settings.max = Math.max(1, Math.min(500, parseInt(els.max.value, 10) || LF.DEFAULTS.max));
    settings.cc = (els.cc.value || '').replace(/\D/g, '') || LF.DEFAULTS.cc;
    settings.deep = els.deep.checked;
    settings.emails = els.emails.checked;
    settings.onlyEmail = els.onlyEmail.checked;
    settings.onlyPhone = els.onlyPhone.checked;
    settings.noWebsite = els.noWebsite.checked;
    settings.hideContacted = els.hideContacted.checked;
    settings.sender = els.sender.value.trim().slice(0, 60);
    for (const id of ['msgWa', 'emailSubject', 'emailBody']) settings[id] = els[id].value.slice(0, id === 'emailBody' ? 1500 : id === 'msgWa' ? 800 : 150);
    els.max.value = settings.max; els.cc.value = settings.cc;
    saveSettings();
  }

  function setStatus(msg, level) { els.status.textContent = msg; els.status.className = 'status' + (level ? ' ' + level : ''); }
  function setProgress(done, total) { els.bar.style.width = Math.min(100, Math.round((done / Math.max(1, total)) * 100)) + '%'; }
  function setRunning(on) {
    els.start.disabled = on; els.stop.disabled = !on; els.findemail.disabled = on;
    els.start.textContent = on ? 'Running…' : 'Start';
    if (!on) setProgress(0, 1);
  }

  function markContacted(l, kind) {
    l.contacted = { ...(l.contacted || {}), [kind]: Date.now() };
    saveSoon();
    setTimeout(renderSoon, 200);
  }

  const visible = () => LF.applyFilters(Object.values(leads), settings).sort((a, b) => b.addedAt - a.addedAt);

  let renderQueued = false;
  function renderSoon() { if (renderQueued) return; renderQueued = true; requestAnimationFrame(() => { renderQueued = false; render(); }); }

  function render() {
    if (!els.list) return;
    const all = Object.values(leads);
    const list = visible();
    els.badge.textContent = list.length === all.length ? `${all.length} leads` : `${list.length}/${all.length}`;
    els.list.textContent = '';
    if (!list.length) {
      const d = document.createElement('div');
      d.className = 'empty';
      d.textContent = all.length ? 'No leads match your filters.' : 'No leads yet. Press Start and results will appear here live.';
      els.list.appendChild(d);
      return;
    }
    for (const l of list.slice(0, 120)) {
      const it = document.createElement('div'); it.className = 'item';
      const nm = document.createElement('div'); nm.className = 'nm'; nm.textContent = l.name; nm.title = 'Open in Maps';
      nm.onclick = () => window.open(l.url, '_blank', 'noopener');
      const meta = document.createElement('div'); meta.className = 'meta';
      const bits = [];
      const ph = document.createElement('span');
      if (l.phone) ph.textContent = l.phone; else { ph.textContent = l.detailed ? 'no phone' : 'phone pending'; ph.className = 'nophone'; }
      bits.push(ph);
      if (l.detailed) {
        const w = document.createElement('span');
        if (l.website) { try { w.textContent = new URL(l.website).hostname.replace(/^www\./, ''); } catch (e) { w.textContent = 'website'; } }
        else { w.textContent = 'no website'; w.className = 'hot'; }
        bits.push(w);
      }
      if (l.email) { const em = document.createElement('span'); em.textContent = l.email.split('; ')[0]; em.className = 'hot'; bits.push(em); }
      if (l.rating) bits.push(document.createTextNode(`★ ${l.rating}${l.reviews ? ' (' + l.reviews + ')' : ''}`));
      bits.forEach((b, i) => { if (i) meta.appendChild(document.createTextNode('  ·  ')); meta.appendChild(b); });
      it.append(nm, meta);

      // One-click outreach. These are plain links: the app opens with the text filled in and the person presses send.
      const links = LF.outreachLinks(l, settings);
      const acts = document.createElement('div'); acts.className = 'acts';
      const addAct = (kind, label, href, newTab, tip, offTip) => {
        if (!href) { const s = document.createElement('span'); s.className = 'off'; s.textContent = label; s.title = offTip; acts.appendChild(s); return; }
        const a = document.createElement('a');
        a.href = href; a.textContent = label; a.title = tip;
        if (newTab) { a.target = '_blank'; a.rel = 'noopener'; }
        a.addEventListener('click', ev => { ev.stopPropagation(); markContacted(l, kind); });
        acts.appendChild(a);
      };
      addAct('whatsapp', 'WhatsApp', links.whatsapp, true, 'Open WhatsApp with your message filled in', 'No valid phone number');
      addAct('gmail', 'Gmail', links.gmail, true, 'Open a Gmail draft with subject and text filled in', 'No email found for this lead');
      addAct('sms', 'SMS', links.sms, false, 'Open your messaging app (needs a phone or Phone Link)', 'No valid phone number');
      addAct('call', 'Call', links.call, false, 'Open your calling app (needs a phone or Phone Link)', 'No valid phone number');
      it.appendChild(acts);
      if (l.contacted && Object.keys(l.contacted).length) {
        const done = document.createElement('div'); done.className = 'done';
        const names = { whatsapp: 'WhatsApp', gmail: 'Gmail', sms: 'SMS', call: 'Call' };
        done.textContent = '✓ Opened: ' + Object.keys(l.contacted).map(k => names[k] || k).join(', ');
        it.appendChild(done);
      }
      els.list.appendChild(it);
    }
  }

  /* ----------------------------- license ----------------------------- */
  let licensed = false;

  async function getLicense() {
    try { return (await chrome.runtime.sendMessage({ type: 'lf-license', force: true })) || { ok: false, state: 'error' }; }
    catch (e) { return { ok: false, state: 'error' }; }
  }

  let licInfo = {};

  function mount(l) {
    licInfo = l; licensed = !!l.ok;
    if (licensed) {
      buildPanel(); fillLicLine(l); render();
      if (l.mode === 'development') root.querySelector('.brand').textContent = 'Maps Lead Finder · DEVELOPMENT';
      else if (l.owner) root.querySelector('.brand').textContent = 'Maps Lead Finder · OWNER';
    } else buildLockedPanel(l);
  }

  function fillLicLine(l) {
    const who = l.name || l.email || 'Approved account';
    const exp = l.expires ? 'until ' + new Date(l.expires).toISOString().slice(0, 10) : 'no expiry';
    els.licText.textContent = `✓ ${who} · ${exp}`;
    els.deact.textContent = 'Sign out';
    els.deact.title = 'Sign out of this extension';
    els.deact.onclick = async () => {
      run.stop = true; licensed = false;
      try {
        const r = await chrome.runtime.sendMessage({ type: 'lf-deactivate' });
        host.remove(); mount(r || { ok: false, state: 'signedout' });
      } catch { setStatus('Could not sign out. Reload the page.', 'err'); }
    };
  }

  function buildLockedPanel(l) {
    host = document.createElement('div');
    host.id = 'maps-lead-finder-host';
    host.style.cssText = 'position:fixed;top:72px;right:16px;z-index:2147483647;';
    root = host.attachShadow({ mode: 'open' });
    root.innerHTML = `<style>${CSS}</style>
      <div class="panel">
        <div class="head"><span class="logo" role="img" aria-label="Haseeb Crafts"></span>
          <div class="ttl"><div class="brand">Maps Lead Finder</div><div class="sub">Haseeb Crafts · Account access</div></div>
          <button class="icon" id="hide" title="Hide">✕</button></div>
        <div class="body lock"><div class="state"><div><b>Account access required</b><p id="accountmsg"></p></div></div>
          <div class="row"><button class="btn primary" id="signin">Sign in</button><button class="btn" id="portal">My access</button><button class="btn" id="refresh">Refresh</button></div>
          <p>No license key is needed. Internet and owner approval are required.</p>
        </div>
      </div>`;
    document.documentElement.appendChild(host);
    root.getElementById('accountmsg').textContent = LF.lockMessage(l);
    root.getElementById('hide').onclick = () => { host.style.display = 'none'; };
    root.getElementById('signin').onclick = () => chrome.runtime.sendMessage({ type: 'hc-signin' });
    root.getElementById('portal').onclick = () => chrome.runtime.sendMessage({ type: 'hc-portal' });
    root.getElementById('refresh').onclick = async () => {
      const result = await getLicense(); host.remove(); mount(result);
    };
  }

  async function ensureAccess() {
    const result = await getLicense();
    licensed = !!result.ok;
    if (!licensed) { run.stop = true; if (host) host.remove(); mount(result); }
    return licensed;
  }

  /* ------------------------------ init ------------------------------ */
  async function init() {
    try {
      const r = await chrome.storage.local.get(['leads', 'settings']);
      leads = r.leads || {};
      settings = { ...LF.DEFAULTS, ...(r.settings || {}) };
    } catch (e) { /* storage unavailable */ }
    mount(await getLicense());
    let accessChecking = false;
    setInterval(async () => {
      if (accessChecking) return;
      accessChecking = true;
      try {
        const st = await getLicense();
        if (!st.ok) {
          licensed = false; run.stop = true;
          if (!run.active) { if (host) host.remove(); mount(st); }
        } else if (!licensed) {
          if (host) host.remove(); mount(st);
        }
      } finally { accessChecking = false; }
    }, 5000);

    chrome.storage.onChanged.addListener(ch => {
      // If "Clear" was pressed in the popup, clear here too. (Other changes are ignored; we write them ourselves.)
      if(ch.hcAccess && !run.active) {
        const state = ch.hcAccess.newValue || {ok:false,state:'signedout'};
        if(state.ok !== licensed || (!state.ok && state.state !== licInfo.state)) { if(host)host.remove();mount(state); }
      }
      if (ch.leads && (!ch.leads.newValue || !Object.keys(ch.leads.newValue).length) && !run.active) { leads = {}; render(); }
    });
    chrome.runtime.onMessage.addListener((msg, _s, send) => {
      if(msg?.type === 'hc-access-updated') {
        const st=msg.access;
        if(!st.ok){licensed=false;run.stop=true;}
        if(!run.active){ if(host)host.remove();mount(st); }
        send({ok:true});
      }
      if (msg && (msg.type === 'lf-toggle' || msg.type === 'lf-show')) {
        host.style.display = msg.type === 'lf-show' ? '' : (host.style.display === 'none' ? '' : 'none');
        send({ ok: true });
      }
    });
  }
  init();
})();
