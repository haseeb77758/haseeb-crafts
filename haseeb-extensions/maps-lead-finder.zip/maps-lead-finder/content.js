(() => {
  'use strict';
  if (window.__mapsLeadFinder) return;
  window.__mapsLeadFinder = true;
  const LF = globalThis.LF;

  /* ------------------------------------------------------------------
   * SELECTORS — if Google changes the Maps layout and something stops
   * working, this is the only place you need to fix.
   * ------------------------------------------------------------------ */
  const SEL = {
    feed: 'div[role="feed"]',
    placeLink: 'a[href*="/maps/place/"]',
    card: 'div.Nv2PK',
    phone: 'button[data-item-id^="phone"]',
    website: 'a[data-item-id="authority"]',
    address: 'button[data-item-id="address"]',
    category: 'button[jsaction*="category"]',
    infoText: '.Io6YTe',
    back: 'button[aria-label="Back"]'
  };

  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const $ = (s, r = document) => r.querySelector(s);
  const norm = s => (s || '').toLowerCase().replace(/\s+/g, ' ').trim();

  async function waitFor(fn, timeout = 6000, step = 150) {
    const t = Date.now();
    while (Date.now() - t < timeout) {
      const v = fn();
      if (v) return v;
      await sleep(step);
    }
    return null;
  }

  /* ------------------------------ state ------------------------------ */
  let leads = {};
  let settings = { ...LF.DEFAULTS };
  const run = { active: false, stop: false, keys: new Set(), query: '' };

  let saveTimer = null;
  function saveSoon() {
    clearTimeout(saveTimer);
    saveTimer = setTimeout(() => { try { chrome.storage.local.set({ leads }); } catch (e) { /* extension reloaded */ } }, 400);
  }
  function saveSettings() { try { chrome.storage.local.set({ settings }); } catch (e) { /* ignore */ } }

  /* --------------------------- page helpers --------------------------- */
  const keyOf = href => LF.placeKey(href);
  const coordsOf = href => LF.placeCoords(href);
  function currentQuery() {
    const box = $('#searchboxinput');
    if (box && box.value) return box.value.trim();
    const m = location.pathname.match(/\/maps\/search\/([^/]+)/);
    return m ? decodeURIComponent(m[1].replace(/\+/g, ' ')) : '';
  }
  function findLink(key) {
    const feed = $(SEL.feed);
    if (!feed) return null;
    for (const a of feed.querySelectorAll(SEL.placeLink)) if (keyOf(a.href) === key) return a;
    return null;
  }
  function clickBack(allowHistory) {
    const b = $(SEL.back);
    if (b) { b.click(); return true; }
    if (allowHistory) { history.back(); return true; }
    return false;
  }

  /* --------------------------- card parsing --------------------------- */
  // The text classification (rating vs review count vs phone vs address) lives in shared.js (LF.parseCardText)
  // so it can be tested without a browser. Here we only read the DOM.

  function parseCard(a) {
    const name = (a.getAttribute('aria-label') || '').trim();
    if (!name) return null;
    const card = a.closest(SEL.card) || a.parentElement || a;
    const img = card.querySelector('span[role="img"]');
    const telEl = card.querySelector('a[href^="tel:"]');          // prefer a real tel: link when the card has one
    const parsed = LF.parseCardText({
      name,
      lines: (card.innerText || '').split('\n'),
      ratingLabel: (img && img.getAttribute('aria-label')) || '',
      tel: telEl ? telEl.getAttribute('href') : '',
      cc: settings.cc
    });
    const { lat, lng } = coordsOf(a.href);
    return { name, ...parsed, url: a.href, lat, lng };
  }

  function upsert(p) {
    const old = leads[p.key];
    if (old) {
      for (const f of ['category', 'phone', 'address', 'rating', 'reviews']) if (!old[f] && p[f]) old[f] = p[f];
      old.url = p.url;
      return false;
    }
    leads[p.key] = { ...p, website: '', detailed: false, query: run.query, addedAt: Date.now() };
    return true;
  }

  function collectCards(feed, max) {
    for (const a of feed.querySelectorAll(SEL.placeLink)) {
      if (run.keys.size >= max) break;
      const key = keyOf(a.href);
      if (run.keys.has(key)) continue;
      const p = parseCard(a);
      if (!p) continue;
      p.key = key;
      run.keys.add(key);
      upsert(p);
    }
    saveSoon();
    renderSoon();
  }

  /* ----------------------------- scanning ----------------------------- */
  async function scanList(feed) {
    const max = settings.max;
    let stagnant = 0, last = -1;
    while (!run.stop) {
      collectCards(feed, max);
      const count = run.keys.size;
      setStatus(`Collecting listings… ${count}/${max}`);
      setProgress(count, max);
      if (count >= max) break;
      if (count === last) stagnant++; else { stagnant = 0; last = count; }
      const tail = (feed.innerText || '').slice(-300);
      if (/reached the end of the list|end of the list/i.test(tail)) break;
      if (stagnant >= 5) break;
      feed.scrollTo({ top: feed.scrollHeight, behavior: 'auto' });
      await sleep(1100 + Math.random() * 500);
    }
    collectCards(feed, max);
  }

  let lastDetailName = '';
  async function fetchDetails(key) {
    const lead = leads[key];
    let a = findLink(key);
    if (!a) {
      clickBack(true);
      a = await waitFor(() => findLink(key), 5000);
    }
    if (!a) return false;

    a.scrollIntoView({ block: 'center' });
    a.click();

    const want = norm(lead.name);
    const nameOk = h => { const t = norm(h.textContent); return t && (t === want || t.includes(want) || want.includes(t)); };
    const hexKey = /^0x/i.test(key);
    const findH1 = strict => [...document.querySelectorAll('h1')].find(h =>
      nameOk(h) && (!strict || !hexKey || location.href.includes(key)));

    let h1 = await waitFor(() => findH1(true), 8000);
    if (!h1 && norm(lastDetailName) !== want) h1 = findH1(false); // strict match first, so same-name branches don't get mixed up
    if (!h1) return false;

    const root = h1.closest('[role="main"]') || document;
    await waitFor(() => $(SEL.address, root) || $(SEL.phone, root) || $(SEL.website, root), 3500);
    await sleep(350);

    const text = el => {
      if (!el) return '';
      const t = $(SEL.infoText, el);
      return ((t ? t.textContent : el.getAttribute('aria-label') || el.textContent) || '').replace(/^[^:]{2,20}:\s*/, '').trim();
    };

    const pb = $(SEL.phone, root);
    let phone = '';
    if (pb) {
      const t = $(SEL.infoText, pb);
      phone = t ? t.textContent.trim() : (pb.getAttribute('data-item-id') || '').replace(/^phone:tel:/, '');
    }
    const web = $(SEL.website, root);
    const address = text($(SEL.address, root));
    const cat = ($(SEL.category, root) || {}).textContent;

    lead.phone = phone || lead.phone;
    lead.website = web ? web.href : '';
    lead.address = address || lead.address;
    lead.category = (cat || '').trim() || lead.category;
    lead.detailed = true;
    lastDetailName = lead.name;
    saveSoon();
    renderSoon();
    return true;
  }

  async function deepScan(keys) {
    const todo = keys.filter(k => leads[k] && !leads[k].detailed);
    let i = 0;
    for (const k of todo) {
      if (run.stop) break;
      setStatus(`Phone & website ${i + 1}/${todo.length} — ${leads[k].name}`);
      setProgress(i, todo.length);
      try { await fetchDetails(k); } catch (e) { console.warn('[Lead Finder] details failed', leads[k].name, e); }
      i++;
      await sleep(400 + Math.random() * 500);
    }
    setProgress(todo.length, todo.length || 1);
  }

  /* ------------------------------ emails ------------------------------ */
  const SOCIAL = /(^|\.)(facebook|fb|instagram|linkedin|twitter|x|tiktok|youtube|wa|whatsapp|linktr|t)\.(com|me|ee)$/i;

  async function findEmail(key) {
    const lead = leads[key];
    if (!lead || !lead.website || lead.emailChecked) return;
    let host = '';
    try { host = new URL(lead.website).hostname; } catch (e) { lead.emailChecked = true; return; }
    if (SOCIAL.test(host)) { lead.emailChecked = true; lead.social = lead.website; return; } // behind a login wall, can't be scraped
    try {
      const res = await chrome.runtime.sendMessage({ type: 'lf-find-email', url: lead.website });
      if (res && res.ok) { lead.email = (res.emails || []).join('; '); lead.emailChecked = true; }
    } catch (e) { /* background worker unreachable; will retry next time */ }
    saveSoon();
    renderSoon();
  }

  async function emailPass(keys) {
    const todo = keys.filter(k => leads[k] && leads[k].website && !leads[k].emailChecked);
    let next = 0, done = 0;
    const worker = async () => {
      while (next < todo.length && !run.stop) {
        const k = todo[next++];
        setStatus(`Finding emails ${done + 1}/${todo.length} — ${leads[k].name}`);
        await findEmail(k);
        done++;
        setProgress(done, todo.length);
      }
    };
    if (todo.length) await Promise.all([worker(), worker(), worker()]);
  }

  async function runEmailsOnly() {
    if (run.active || !licensed || !(await ensureAccess())) return;
    readInputs();
    run.active = true; run.stop = false;
    setRunning(true);
    try {
      const keys = Object.keys(leads);
      const pending = keys.filter(k => leads[k].website && !leads[k].emailChecked).length;
      if (!pending) { setStatus('No new websites to check for emails. Run Start with "Also get phone and website" first.', 'warn'); return; }
      await emailPass(keys);
      const found = keys.filter(k => leads[k].email).length;
      setStatus(run.stop ? 'Stopped.' : `Done — ${found} leads have an email.`, run.stop ? 'warn' : 'ok');
    } catch (e) {
      setStatus('Error: ' + e.message, 'err');
    } finally {
      run.active = false; setRunning(false); saveSoon(); render();
    }
  }

  async function startRun() {
    if (run.active || !licensed || !(await ensureAccess())) return;
    readInputs();
    run.active = true; run.stop = false; run.keys = new Set();
    setRunning(true);
    try {
      let feed = $(SEL.feed);
      if (!feed && clickBack(false)) feed = await waitFor(() => $(SEL.feed), 4000);
      if (!feed) {
        setStatus('No search results found. Search on Maps first (for example "dentist in Rawalpindi"), then press Start.', 'warn');
        return;
      }
      run.query = currentQuery();
      await scanList(feed);
      if (settings.deep && !run.stop) await deepScan([...run.keys]);
      if (settings.deep && settings.emails && !run.stop) await emailPass([...run.keys]);
      const n = run.keys.size;
      const em = [...run.keys].filter(k => leads[k] && leads[k].email).length;
      const tail = settings.deep && settings.emails ? `, ${em} with email` : '';
      setStatus(run.stop ? `Stopped — ${n} leads saved.` : `Done — ${n} leads collected${tail}.`, run.stop ? 'warn' : 'ok');
    } catch (e) {
      console.error('[Lead Finder]', e);
      setStatus('Error: ' + e.message, 'err');
    } finally {
      run.active = false;
      setRunning(false);
      saveSoon();
      render();
    }
  }

  /* ------------------------------- UI ------------------------------- */
  const CSS = `
    :host { all: initial; }
    * { box-sizing: border-box; font-family: system-ui, -apple-system, "Segoe UI", Roboto, sans-serif; }
    .panel { width: 370px; max-width: calc(100vw - 32px); background: #f5fbf7; color: #163425; border: 1px solid #c9e4d2; border-radius: 14px;
      box-shadow: 0 14px 38px rgba(0,0,0,.28); font-size: 13px; overflow: hidden; }
    .head { position: relative; display: flex; align-items: center; gap: 10px; padding: 12px 10px 11px 14px; color: #fff; cursor: move; user-select: none;
      background: #0b2418 radial-gradient(120% 160% at 0% 0%, #1e5133 0%, #0b2418 62%); }
    .head:before { content: ""; position: absolute; left: 0; right: 0; top: 0; height: 3px; background: linear-gradient(90deg, #168348, #9de5b5 50%, #168348); }
    .logo { flex: none; display: flex; flex-direction: column; align-items: center; justify-content: center; width: 62px; min-height: 54px; border: 1px solid #3c7752; background: #153d27; border-radius: 12px; color: #b7f2cc; }
    .logo b { font-size: 27px; line-height: 1; letter-spacing: -.07em; font-weight: 850; }
    .logo small { font-size: 8px; line-height: 1.2; margin-top: 5px; letter-spacing: 0; color: #d6f4e0; }
    .location-pin { width: 18px; height: 22px; flex: none; color: #61db90; }
    .brand { display: flex; align-items: center; gap: 6px; }
    .credit { padding: 11px 14px; text-align: center; border-top: 1px solid #d5e9dc; background: #ecf7f0; color: #52725f; font-size: 11px; }
    .credit strong { color: #17613b; }
    .btn, .icon { transition: background .18s ease, box-shadow .18s ease; }
    .btn.primary:hover { box-shadow: 0 4px 12px #19884d25; }
    @media(prefers-reduced-motion:reduce) { .btn,.icon { transition:none; } }
    .ttl { flex: 1; min-width: 0; }
    .brand { font-weight: 800; font-size: 13px; letter-spacing: .02em; text-transform: uppercase; color: #9de5b5; line-height: 1.2; }
    .sub { font-size: 11px; color: #b3d6bf; margin-top: 1px; }
    .badge { background: rgba(97,219,144,.14); border: 1px solid rgba(97,219,144,.45); color: #c4f5d3; border-radius: 999px; padding: 2px 9px; font-size: 12px; font-variant-numeric: tabular-nums; white-space: nowrap; }
    .icon { all: unset; cursor: pointer; width: 24px; height: 24px; display: grid; place-items: center; border-radius: 6px; font-size: 14px; color: #d9f0e1; }
    .icon:hover { background: rgba(255,255,255,.15); }
    .body { padding: 12px 14px 14px; display: grid; gap: 10px; }
    .body.min { display: none; }
    .row { display: flex; gap: 10px; }
    .field { display: grid; gap: 4px; flex: 1; font-size: 12px; color: #42634e; }
    input[type=number], input[type=text] { width: 100%; padding: 6px 8px; border: 1px solid #b7d7c1; border-radius: 7px; font-size: 13px; color: #163425; background: #fff; }
    input:focus-visible, button:focus-visible, textarea:focus-visible, .btn:focus-within { outline: 2px solid #19884d; outline-offset: 1px; }
    .chk { display: flex; align-items: flex-start; gap: 8px; font-size: 12.5px; line-height: 1.35; cursor: pointer; }
    .chk input { margin: 2px 0 0; accent-color: #19884d; }
    .chk small { color: #587662; display: block; }
    .btns { display: flex; gap: 8px; }
    .btn { all: unset; box-sizing: border-box; display: inline-block; cursor: pointer; text-align: center; padding: 8px 12px; border-radius: 8px; font-weight: 700; font-size: 13px;
      border: 1px solid #19884d; background: #fff; color: #17613b; flex: 1; font-family: system-ui, -apple-system, "Segoe UI", Roboto, sans-serif; }
    .btn:hover { background: #edf8f0; }
    .btn.primary { background: linear-gradient(#32aa66, #19884d); border-color: #167541; color: #ffffff; flex: 2; }
    .btn.primary:hover { background: linear-gradient(#43bd78, #1c9152); }
    .btn[disabled], .btn.dis { opacity: .45; cursor: not-allowed; }
    .btn.danger { color: #b42318; border-color: #e8bcb7; }
    .btn.sm { flex: none; padding: 4px 10px; font-size: 12px; }
    .btn.file input { display: none; }
    .status { min-height: 18px; font-size: 12px; color: #42634e; line-height: 1.4; }
    .status.ok { color: #1e8a5e; } .status.warn { color: #9a5b00; } .status.err { color: #b42318; }
    .bar { height: 4px; background: #dceee2; border-radius: 4px; overflow: hidden; }
    .bar > div { height: 100%; width: 0; background: #19884d; transition: width .25s; }
    .list { max-height: 300px; overflow: auto; border: 1px solid #d5e9dc; border-radius: 8px; background: #f8fcf9; }
    .item { padding: 7px 10px; border-bottom: 1px solid #e2f0e6; }
    .item:last-child { border-bottom: 0; }
    .item:hover { background: #edf8f0; }
    .nm { font-weight: 600; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; cursor: pointer; }
    .nm:hover { text-decoration: underline; }
    .meta { font-size: 11.5px; color: #52725f; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
    .meta .nophone { color: #9a5b00; } .meta .hot { color: #1e8a5e; font-weight: 600; }
    .empty { padding: 18px 12px; text-align: center; color: #587662; font-size: 12.5px; line-height: 1.5; }
    .foot { display: flex; gap: 8px; }
    .foot .btn { font-size: 12px; padding: 7px 8px; }
    .acts { display: flex; flex-wrap: wrap; gap: 5px; margin-top: 6px; }
    .acts a { font-size: 11.5px; font-weight: 600; padding: 3px 10px; border-radius: 99px; border: 1px solid #c0deca; background: #fff; color: #17613b; text-decoration: none; }
    .acts a:hover { background: #edf8f0; }
    .acts a:focus-visible { outline: 2px solid #19884d; outline-offset: 1px; }
    .acts .off { font-size: 11.5px; padding: 3px 10px; border-radius: 99px; border: 1px dashed #c9dcd0; color: #7a9686; }
    .done { font-size: 11px; color: #1e8a5e; margin-top: 3px; }
    details.tpl { border-top: 1px solid #d5e9dc; padding-top: 8px; }
    details.tpl summary { cursor: pointer; font-size: 12.5px; font-weight: 600; }
    .tpl .col { display: grid; gap: 8px; margin-top: 8px; }
    .tpl textarea { min-height: 64px; font: 12px system-ui, sans-serif; }
    .tpl .hint { color: #587662; font-size: 11.5px; line-height: 1.4; }
    textarea { width: 100%; min-height: 76px; padding: 8px; border: 1px solid #b7d7c1; border-radius: 7px; font: 12px ui-monospace, Consolas, monospace; resize: vertical; color: #163425; background: #fff; }
    textarea[disabled] { background: #ecf5ef; opacity: .7; }
    .licline { display: flex; align-items: center; justify-content: space-between; gap: 8px; font-size: 11.5px; color: #17613b; background: #edf8f0; border: 1px solid #c5e4cf; border-radius: 8px; padding: 5px 9px; }
    .lnk { all: unset; cursor: pointer; color: #17613b; text-decoration: underline; font-size: 11.5px; white-space: nowrap; }
    .state { display: flex; gap: 10px; align-items: flex-start; padding: 10px 12px; border-radius: 10px; background: #eef8f1; border: 1px solid #c2e4cc; }
    .state.err { background: #fdf2f1; border-color: #f0c4be; } .state.info { background: #edf8f0; border-color: #c5e4cf; }
    .sicon { font-size: 20px; line-height: 1.2; }
    .state b { display: block; font-size: 13.5px; color: #163425; }
    .state p { margin: 2px 0 0; font-size: 12px; color: #42634e; line-height: 1.45; }
    .acct { display: flex; align-items: center; justify-content: space-between; gap: 10px; padding: 8px 10px; border: 1px solid #d5e9dc; border-radius: 10px; background: #f8fcf9; }
    .acct small { display: block; color: #587662; font-size: 11px; } .acct b { font-size: 12.5px; word-break: break-all; }
    .sec { display: grid; gap: 8px; padding: 10px; border: 1px solid #d5e9dc; border-radius: 10px; }
    .sech { font-size: 11px; font-weight: 800; letter-spacing: .08em; text-transform: uppercase; color: #17613b; }
    .lock label { display: grid; gap: 4px; font-size: 12px; font-weight: 600; color: #163425; }
    .lock label.btn { display: inline-block; font-weight: 700; color: #17613b; }
    .lock label small { font-weight: 400; color: #587662; line-height: 1.4; }
    .ownerline { font-size: 11.5px; color: #587662; }
    [hidden] { display: none !important; }
  `;

  const HTML = `
    <style>${CSS}</style>
    <div class="panel">
      <div class="head" id="drag">
        <span class="logo" role="img" aria-label="HC Haseeb Crafts"><b>HC</b><small>Haseeb Crafts</small></span>
        <div class="ttl"><div class="brand"><svg class="location-pin" viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M20 10c0 5.5-8 12-8 12S4 15.5 4 10a8 8 0 1 1 16 0Z" fill="currentColor"/><circle cx="12" cy="10" r="3" fill="#123c28"/></svg>Maps Lead Finder</div><div class="sub">HC tools · v2.2.0</div></div>
        <div class="badge" id="badge">0</div>
        <button class="icon" id="min" title="Minimize">–</button>
        <button class="icon" id="hide" title="Hide (bring it back from the toolbar icon)">✕</button>
      </div>
      <div class="body" id="body">
        <div class="licline"><span id="licText"></span><button class="lnk" id="deact" title="Remove the license from this browser">Deactivate</button></div>
        <div class="row">
          <label class="field">Max leads<input type="number" id="max" min="1" max="500"></label>
          <label class="field">Country code<input type="text" id="cc" maxlength="4" placeholder="92"></label>
        </div>
        <label class="chk"><input type="checkbox" id="deep"><span>Also get phone and website<small>Opens every listing, so it is slower but the data is complete.</small></span></label>
        <label class="chk"><input type="checkbox" id="emails"><span>Also find emails from websites<small>Only for leads that have a website. Checks the homepage and contact page.</small></span></label>
        <div class="row">
          <label class="chk"><input type="checkbox" id="onlyPhone"><span>Only with phone</span></label>
          <label class="chk"><input type="checkbox" id="onlyEmail"><span>Only with email</span></label>
        </div>
        <label class="chk"><input type="checkbox" id="noWebsite"><span>No website (hot leads)</span></label>
        <label class="chk"><input type="checkbox" id="hideContacted"><span>Hide leads I already contacted</span></label>
        <div class="btns">
          <button class="btn primary" id="start">Start</button>
          <button class="btn" id="stop" disabled>Stop</button>
        </div>
        <button class="btn" id="findemail">Find emails for saved leads</button>
        <div class="status" id="status">Search on Maps (e.g. "dentist in Rawalpindi"), then press Start.</div>
        <div class="bar"><div id="bar"></div></div>
        <div class="list" id="list"></div>
        <details class="tpl">
          <summary>Message templates (WhatsApp, SMS, Gmail)</summary>
          <div class="col">
            <label class="field">Your name or business ({sender})<input type="text" id="sender" maxlength="60" placeholder="e.g. Haseeb Crafts"></label>
            <label class="field">WhatsApp and SMS message<textarea id="msgWa" maxlength="800" spellcheck="false"></textarea></label>
            <label class="field">Email subject<input type="text" id="emailSubject" maxlength="150"></label>
            <label class="field">Email body<textarea id="emailBody" maxlength="1500" spellcheck="false"></textarea></label>
            <div class="hint">Use {name}, {category} and {sender}. The WhatsApp, Gmail, SMS and Call buttons on each lead open the app with this text filled in. You press send yourself, one lead at a time.</div>
            <button class="btn" id="tplReset">Reset templates</button>
          </div>
        </details>
        <div class="foot">
          <button class="btn" id="csv">Export CSV</button>
          <button class="btn" id="copy">Phones</button>
          <button class="btn" id="copyem">Emails</button>
          <button class="btn danger" id="clear">Clear</button>
        </div>
      </div>
      <div class="credit">Made by <strong>Haseeb Crafts</strong></div>
    </div>`;

  let host, root, els = {};

  function buildPanel() {
    host = document.createElement('div');
    host.id = 'maps-lead-finder-host';
    host.style.cssText = 'position:fixed;top:72px;right:16px;z-index:2147483647;';
    root = host.attachShadow({ mode: 'open' });
    root.innerHTML = HTML;
    document.documentElement.appendChild(host);
    for (const id of ['badge', 'min', 'hide', 'body', 'max', 'cc', 'deep', 'emails', 'onlyPhone', 'onlyEmail', 'noWebsite', 'hideContacted', 'licText', 'deact', 'sender', 'msgWa', 'emailSubject', 'emailBody', 'tplReset', 'findemail', 'copyem', 'start', 'stop', 'status', 'bar', 'list', 'csv', 'copy', 'clear', 'drag']) {
      els[id] = root.getElementById(id);
    }

    els.max.value = settings.max;
    els.cc.value = settings.cc;
    els.deep.checked = settings.deep;
    els.emails.checked = settings.emails;
    els.onlyEmail.checked = settings.onlyEmail;
    els.onlyPhone.checked = settings.onlyPhone;
    els.noWebsite.checked = settings.noWebsite;
    els.hideContacted.checked = settings.hideContacted;
    for (const id of ['sender', 'msgWa', 'emailSubject', 'emailBody']) els[id].value = settings[id] || '';

    els.start.onclick = startRun;
    els.findemail.onclick = runEmailsOnly;
    els.stop.onclick = () => { run.stop = true; setStatus('Stopping…', 'warn'); };
    els.min.onclick = () => els.body.classList.toggle('min');
    els.hide.onclick = () => { host.style.display = 'none'; };
    for (const id of ['onlyPhone', 'onlyEmail', 'noWebsite', 'hideContacted', 'cc', 'sender', 'msgWa', 'emailSubject', 'emailBody']) els[id].onchange = () => { readInputs(); render(); };
    els.tplReset.onclick = () => {
      for (const id of ['msgWa', 'emailSubject', 'emailBody']) { settings[id] = LF.DEFAULTS[id]; els[id].value = LF.DEFAULTS[id]; }
      saveSettings(); render(); setStatus('Message templates reset.', 'ok');
    };
    els.max.onchange = els.deep.onchange = els.emails.onchange = readInputs;

    els.csv.onclick = async () => {
      if (!(await ensureAccess())) return;
      const list = visible();
      if (!list.length) return setStatus('No leads to export (check your filters).', 'warn');
      LF.download(list, settings);
      setStatus(`${list.length} leads exported to CSV.`, 'ok');
    };
    els.copy.onclick = async () => {
      if (!(await ensureAccess())) return;
      const nums = [...new Set(visible().map(l => l.phone).filter(Boolean))];
      if (!nums.length) return setStatus('No phone numbers to copy.', 'warn');
      const txt = nums.join('\n');
      try { await navigator.clipboard.writeText(txt); }
      catch (e) {
        const ta = document.createElement('textarea'); ta.value = txt; document.body.appendChild(ta); ta.select();
        document.execCommand('copy'); ta.remove();
      }
      setStatus(`${nums.length} phone numbers copied.`, 'ok');
    };
    els.copyem.onclick = async () => {
      const em = [...new Set(visible().flatMap(l => (l.email || '').split('; ')).filter(Boolean))];
      if (!em.length) return setStatus('No emails to copy.', 'warn');
      const txt = em.join('\n');
      try { await navigator.clipboard.writeText(txt); }
      catch (e) {
        const ta = document.createElement('textarea'); ta.value = txt; document.body.appendChild(ta); ta.select();
        document.execCommand('copy'); ta.remove();
      }
      setStatus(`${em.length} emails copied.`, 'ok');
    };
    els.clear.onclick = () => {
      if (run.active) return setStatus('Stop the run first, then Clear.', 'warn');
      if (!Object.keys(leads).length) return;
      if (!confirm('Delete all saved leads?')) return;
      leads = {}; saveSoon(); render(); setStatus('All leads cleared.');
    };

    // drag
    let drag = null;
    els.drag.addEventListener('pointerdown', e => {
      if (e.target.closest('button')) return;
      const r = host.getBoundingClientRect();
      drag = { dx: e.clientX - r.left, dy: e.clientY - r.top };
      els.drag.setPointerCapture(e.pointerId);
    });
    els.drag.addEventListener('pointermove', e => {
      if (!drag) return;
      const x = Math.min(Math.max(0, e.clientX - drag.dx), window.innerWidth - 80);
      const y = Math.min(Math.max(0, e.clientY - drag.dy), window.innerHeight - 40);
      host.style.left = x + 'px'; host.style.top = y + 'px'; host.style.right = 'auto';
    });
    els.drag.addEventListener('pointerup', () => { drag = null; });
  }

  function readInputs() {
    settings.max = Math.max(1, Math.min(500, parseInt(els.max.value, 10) || LF.DEFAULTS.max));
    settings.cc = (els.cc.value || '').replace(/\D/g, '') || LF.DEFAULTS.cc;
    settings.deep = els.deep.checked;
    settings.emails = els.emails.checked;
    settings.onlyEmail = els.onlyEmail.checked;
    settings.onlyPhone = els.onlyPhone.checked;
    settings.noWebsite = els.noWebsite.checked;
    settings.hideContacted = els.hideContacted.checked;
    settings.sender = els.sender.value.trim().slice(0, 60);
    for (const id of ['msgWa', 'emailSubject', 'emailBody']) settings[id] = els[id].value.slice(0, id === 'emailBody' ? 1500 : id === 'msgWa' ? 800 : 150);
    els.max.value = settings.max; els.cc.value = settings.cc;
    saveSettings();
  }

  function setStatus(msg, level) { els.status.textContent = msg; els.status.className = 'status' + (level ? ' ' + level : ''); }
  function setProgress(done, total) { els.bar.style.width = Math.min(100, Math.round((done / Math.max(1, total)) * 100)) + '%'; }
  function setRunning(on) {
    els.start.disabled = on; els.stop.disabled = !on; els.findemail.disabled = on;
    els.start.textContent = on ? 'Running…' : 'Start';
    if (!on) setProgress(0, 1);
  }

  function markContacted(l, kind) {
    l.contacted = { ...(l.contacted || {}), [kind]: Date.now() };
    saveSoon();
    setTimeout(renderSoon, 200);
  }

  const visible = () => LF.applyFilters(Object.values(leads), settings).sort((a, b) => b.addedAt - a.addedAt);

  let renderQueued = false;
  function renderSoon() { if (renderQueued) return; renderQueued = true; requestAnimationFrame(() => { renderQueued = false; render(); }); }

  function render() {
    if (!els.list) return;
    const all = Object.values(leads);
    const list = visible();
    els.badge.textContent = list.length === all.length ? `${all.length} leads` : `${list.length}/${all.length}`;
    els.list.textContent = '';
    if (!list.length) {
      const d = document.createElement('div');
      d.className = 'empty';
      d.textContent = all.length ? 'No leads match your filters.' : 'No leads yet. Press Start and results will appear here live.';
      els.list.appendChild(d);
      return;
    }
    for (const l of list.slice(0, 120)) {
      const it = document.createElement('div'); it.className = 'item';
      const nm = document.createElement('div'); nm.className = 'nm'; nm.textContent = l.name; nm.title = 'Open in Maps';
      nm.onclick = () => window.open(l.url, '_blank', 'noopener');
      const meta = document.createElement('div'); meta.className = 'meta';
      const bits = [];
      const ph = document.createElement('span');
      if (l.phone) ph.textContent = l.phone; else { ph.textContent = l.detailed ? 'no phone' : 'phone pending'; ph.className = 'nophone'; }
      bits.push(ph);
      if (l.detailed) {
        const w = document.createElement('span');
        if (l.website) { try { w.textContent = new URL(l.website).hostname.replace(/^www\./, ''); } catch (e) { w.textContent = 'website'; } }
        else { w.textContent = 'no website'; w.className = 'hot'; }
        bits.push(w);
      }
      if (l.email) { const em = document.createElement('span'); em.textContent = l.email.split('; ')[0]; em.className = 'hot'; bits.push(em); }
      if (l.rating) bits.push(document.createTextNode(`★ ${l.rating}${l.reviews ? ' (' + l.reviews + ')' : ''}`));
      bits.forEach((b, i) => { if (i) meta.appendChild(document.createTextNode('  ·  ')); meta.appendChild(b); });
      it.append(nm, meta);

      // One-click outreach. These are plain links: the app opens with the text filled in and the person presses send.
      const links = LF.outreachLinks(l, settings);
      const acts = document.createElement('div'); acts.className = 'acts';
      const addAct = (kind, label, href, newTab, tip, offTip) => {
        if (!href) { const s = document.createElement('span'); s.className = 'off'; s.textContent = label; s.title = offTip; acts.appendChild(s); return; }
        const a = document.createElement('a');
        a.href = href; a.textContent = label; a.title = tip;
        if (newTab) { a.target = '_blank'; a.rel = 'noopener'; }
        a.addEventListener('click', ev => { ev.stopPropagation(); markContacted(l, kind); });
        acts.appendChild(a);
      };
      addAct('whatsapp', 'WhatsApp', links.whatsapp, true, 'Open WhatsApp with your message filled in', 'No valid phone number');
      addAct('gmail', 'Gmail', links.gmail, true, 'Open a Gmail draft with subject and text filled in', 'No email found for this lead');
      addAct('sms', 'SMS', links.sms, false, 'Open your messaging app (needs a phone or Phone Link)', 'No valid phone number');
      addAct('call', 'Call', links.call, false, 'Open your calling app (needs a phone or Phone Link)', 'No valid phone number');
      it.appendChild(acts);
      if (l.contacted && Object.keys(l.contacted).length) {
        const done = document.createElement('div'); done.className = 'done';
        const names = { whatsapp: 'WhatsApp', gmail: 'Gmail', sms: 'SMS', call: 'Call' };
        done.textContent = '✓ Opened: ' + Object.keys(l.contacted).map(k => names[k] || k).join(', ');
        it.appendChild(done);
      }
      els.list.appendChild(it);
    }
  }

  /* ----------------------------- license ----------------------------- */
  let licensed = false;

  async function getLicense() {
    try { return (await chrome.runtime.sendMessage({ type: 'lf-license', force: true })) || { ok: false, state: 'error' }; }
    catch (e) { return { ok: false, state: 'error' }; }
  }

  let licInfo = {};

  function mount(l) {
    licInfo = l; licensed = !!l.ok;
    if (licensed) {
      buildPanel(); fillLicLine(l); render();
      if (l.mode === 'development') root.querySelector('.brand').textContent = 'Maps Lead Finder · DEVELOPMENT';
      else if (l.owner) root.querySelector('.brand').textContent = 'Maps Lead Finder · OWNER';
    } else buildLockedPanel(l);
  }

  function fillLicLine(l) {
    const who = l.name || l.email || 'Approved account';
    const exp = l.expires ? 'until ' + new Date(l.expires).toISOString().slice(0, 10) : 'no expiry';
    els.licText.textContent = `✓ ${who} · ${exp}`;
    els.deact.textContent = 'Sign out';
    els.deact.title = 'Sign out of this extension';
    els.deact.onclick = async () => {
      run.stop = true; licensed = false;
      try {
        const r = await chrome.runtime.sendMessage({ type: 'lf-deactivate' });
        host.remove(); mount(r || { ok: false, state: 'signedout' });
      } catch { setStatus('Could not sign out. Reload the page.', 'err'); }
    };
  }

  function buildLockedPanel(l) {
    host = document.createElement('div');
    host.id = 'maps-lead-finder-host';
    host.style.cssText = 'position:fixed;top:72px;right:16px;z-index:2147483647;';
    root = host.attachShadow({ mode: 'open' });
    root.innerHTML = `<style>${CSS}</style>
      <div class="panel">
        <div class="head"><span class="logo" role="img" aria-label="HC Haseeb Crafts"><b>HC</b><small>Haseeb Crafts</small></span>
          <div class="ttl"><div class="brand"><svg class="location-pin" viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M20 10c0 5.5-8 12-8 12S4 15.5 4 10a8 8 0 1 1 16 0Z" fill="currentColor"/><circle cx="12" cy="10" r="3" fill="#123c28"/></svg>Maps Lead Finder</div><div class="sub">Account access · v2.2.0</div></div>
          <button class="icon" id="hide" title="Hide">✕</button></div>
        <div class="body lock"><div class="state"><div><b>Account access required</b><p id="accountmsg"></p></div></div>
          <div class="row"><button class="btn primary" id="signin">Sign in</button><button class="btn" id="portal">My access</button><button class="btn" id="refresh">Refresh</button></div>
          <p>No license key is needed. Internet and owner approval are required.</p>
        </div>
        <div class="credit">Made by <strong>Haseeb Crafts</strong></div>
      </div>`;
    document.documentElement.appendChild(host);
    root.getElementById('accountmsg').textContent = LF.lockMessage(l);
    root.getElementById('hide').onclick = () => { host.style.display = 'none'; };
    root.getElementById('signin').onclick = () => chrome.runtime.sendMessage({ type: 'hc-signin' });
    root.getElementById('portal').onclick = () => chrome.runtime.sendMessage({ type: 'hc-portal' });
    root.getElementById('refresh').onclick = async () => {
      const result = await getLicense(); host.remove(); mount(result);
    };
  }

  async function ensureAccess() {
    const result = await getLicense();
    licensed = !!result.ok;
    if (!licensed) { run.stop = true; if (host) host.remove(); mount(result); }
    return licensed;
  }

  /* ------------------------------ init ------------------------------ */
  async function init() {
    try {
      const r = await chrome.storage.local.get(['leads', 'settings']);
      leads = r.leads || {};
      settings = { ...LF.DEFAULTS, ...(r.settings || {}) };
    } catch (e) { /* storage unavailable */ }
    mount(await getLicense());
    let accessChecking = false;
    setInterval(async () => {
      if (accessChecking) return;
      accessChecking = true;
      try {
        const st = await getLicense();
        if (!st.ok) {
          licensed = false; run.stop = true;
          if (!run.active) { if (host) host.remove(); mount(st); }
        } else if (!licensed) {
          if (host) host.remove(); mount(st);
        }
      } finally { accessChecking = false; }
    }, 5000);

    chrome.storage.onChanged.addListener(ch => {
      // If "Clear" was pressed in the popup, clear here too. (Other changes are ignored; we write them ourselves.)
      if(ch.hcAccess && !run.active) {
        const state = ch.hcAccess.newValue || {ok:false,state:'signedout'};
        if(state.ok !== licensed || (!state.ok && state.state !== licInfo.state)) { if(host)host.remove();mount(state); }
      }
      if (ch.leads && (!ch.leads.newValue || !Object.keys(ch.leads.newValue).length) && !run.active) { leads = {}; render(); }
    });
    chrome.runtime.onMessage.addListener((msg, _s, send) => {
      if(msg?.type === 'hc-access-updated') {
        const st=msg.access;
        if(!st.ok){licensed=false;run.stop=true;}
        if(!run.active){ if(host)host.remove();mount(st); }
        send({ok:true});
      }
      if (msg && (msg.type === 'lf-toggle' || msg.type === 'lf-show')) {
        host.style.display = msg.type === 'lf-show' ? '' : (host.style.display === 'none' ? '' : 'none');
        send({ ok: true });
      }
    });
  }
  init();
})();
