// Background service worker:
//  1) license checks (signature, account, expiry, remote ON/OFF) and
//  2) public-email discovery on business websites, with strict URL validation.
importScripts('auth-config.js');

/* =========================================================================
 * Public URL validation (used for every page we fetch: homepage, contact
 * pages and every redirect hop)
 * ========================================================================= */

function parseIPv4(h) {
  const m = h.match(/^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/);
  if (!m) return null;
  const o = m.slice(1).map(Number);
  return o.every(n => n <= 255) ? o : null;
}

function nonPublicIPv4(o) {
  const [a, b, c] = o;
  return a === 0 || a === 10 || a === 127 ||
    (a === 100 && b >= 64 && b <= 127) ||        // carrier-grade NAT
    (a === 169 && b === 254) ||                  // link-local / cloud metadata
    (a === 172 && b >= 16 && b <= 31) ||
    (a === 192 && b === 0 && (c === 0 || c === 2)) ||
    (a === 192 && b === 168) ||
    (a === 198 && (b === 18 || b === 19)) ||
    (a === 198 && b === 51 && c === 100) ||
    (a === 203 && b === 0 && c === 113) ||
    a >= 224;                                    // multicast, reserved, broadcast
}

function parseIPv6(h) {
  if (h.includes('%')) return null;              // zone ids are never public
  const m4 = h.match(/^(.*:)(\d{1,3}(?:\.\d{1,3}){3})$/);
  if (m4) {
    const o = parseIPv4(m4[2]);
    if (!o) return null;
    h = m4[1] + ((o[0] << 8) | o[1]).toString(16) + ':' + ((o[2] << 8) | o[3]).toString(16);
  }
  const parts = h.split('::');
  if (parts.length > 2) return null;
  const left = parts[0] ? parts[0].split(':') : [];
  const right = parts.length === 2 && parts[1] ? parts[1].split(':') : [];
  if (parts.length === 1 && left.length !== 8) return null;
  if (parts.length === 2 && left.length + right.length > 7) return null;
  const fill = parts.length === 2 ? new Array(8 - left.length - right.length).fill('0') : [];
  const all = [...left, ...fill, ...right];
  if (all.length !== 8) return null;
  const nums = all.map(x => (/^[0-9a-f]{1,4}$/i.test(x) ? parseInt(x, 16) : NaN));
  return nums.some(Number.isNaN) ? null : nums;
}

// Allow-list: only global unicast 2000::/3, minus special-purpose ranges. This rejects ::1, ::, fe80::/10,
// fc00::/7, ff00::/8, ::ffff:a.b.c.d (IPv4-mapped), 64:ff9b::/96 (NAT64) and more.
function publicIPv6(n) {
  if ((n[0] & 0xe000) !== 0x2000) return false;
  if (n[0] === 0x2001 && n[1] < 0x200) return false;                 // 2001::/23 (Teredo, protocol assignments)
  if (n[0] === 0x2001 && n[1] === 0x0db8) return false;              // documentation
  if (n[0] === 0x2002) return false;                                 // 6to4
  if (n[0] === 0x3fff && (n[1] & 0xf000) === 0) return false;        // documentation
  return true;
}

const BLOCKED_SUFFIX = /\.(localhost|local|internal|intranet|lan|home|corp|private|test|example|invalid|localdomain|home\.arpa)$/i;

// Returns { ok: true, url: URL } or { ok: false, reason }.
// NOTE: this checks the text of the URL only. It cannot detect a public-looking hostname whose DNS record points to
// a private address (DNS rebinding); the extension has no API to inspect the resolved address.
function validatePublicUrl(raw) {
  const text = String(raw == null ? '' : raw);
  if (!text || text.length > 2048) return { ok: false, reason: 'invalid-url' };
  let u;
  try { u = new URL(text); } catch (e) { return { ok: false, reason: 'invalid-url' }; }
  if (u.protocol !== 'http:' && u.protocol !== 'https:') return { ok: false, reason: 'scheme' };
  if (u.username || u.password) return { ok: false, reason: 'credentials' };
  if (u.port && u.port !== '80' && u.port !== '443') return { ok: false, reason: 'port' };
  const h = u.hostname.toLowerCase().replace(/\.$/, '');
  if (!h) return { ok: false, reason: 'invalid-url' };
  if (h.startsWith('[')) {
    const n = parseIPv6(h.slice(1, -1));
    return n && publicIPv6(n) ? { ok: true, url: u } : { ok: false, reason: 'non-public-ip' };
  }
  const v4 = parseIPv4(h);
  if (v4) return nonPublicIPv4(v4) ? { ok: false, reason: 'non-public-ip' } : { ok: true, url: u };
  if (/^[\d.]+$/.test(h) || !/^[a-z0-9._-]+$/.test(h)) return { ok: false, reason: 'invalid-host' };
  if (!h.includes('.') || h === 'localhost' || BLOCKED_SUFFIX.test(h)) return { ok: false, reason: 'non-public-host' };
  return { ok: true, url: u };
}

/* =========================================================================
 * Fetching websites
 * Redirects are NOT followed automatically. In an extension service worker a fetch with redirect:'manual'
 * returns an "opaqueredirect" response whose Location is not readable, so a redirect target cannot be
 * validated. When the Location is unreadable we fail safely and only try a few predictable, individually
 * validated alternatives (https, www on/off). Sites that redirect elsewhere (e.g. to /en/) are skipped.
 * ========================================================================= */

const TIMEOUT = 9000;
const MAX_HOPS = 3;
const MAX_BYTES = 1500000;   // pages are read only up to this size

// Reads a response body up to maxBytes and stops downloading beyond that. Returns text or null.
async function readBounded(resp, maxBytes) {
  if (!resp.body || typeof resp.body.getReader !== 'function') return null;   // can't bound it: fail safely
  const reader = resp.body.getReader();
  const chunks = [];
  let total = 0;
  for (;;) {
    const { done, value } = await reader.read();
    if (done) break;
    total += value.byteLength;
    if (total > maxBytes) {
      chunks.push(value.subarray(0, value.byteLength - (total - maxBytes)));
      try { await reader.cancel(); } catch (e) { /* ignore */ }
      break;
    }
    chunks.push(value);
  }
  const out = new Uint8Array(chunks.reduce((n, c) => n + c.byteLength, 0));
  let off = 0;
  for (const c of chunks) { out.set(c, off); off += c.byteLength; }
  return new TextDecoder('utf-8').decode(out);
}

async function safeGet(startUrl) {
  const ctl = new AbortController();
  const timer = setTimeout(() => ctl.abort(), TIMEOUT);
  try {
    let url = startUrl;
    for (let hop = 0; hop <= MAX_HOPS; hop++) {
      const v = validatePublicUrl(url);
      if (!v.ok) return { ok: false, reason: 'blocked-url' };
      let r;
      try {
        r = await fetch(v.url.href, { signal: ctl.signal, redirect: 'manual', credentials: 'omit', cache: 'no-store' });
      } catch (e) { return { ok: false, reason: 'network' }; }
      if (r.type === 'opaqueredirect' || (r.status >= 300 && r.status < 400)) {
        const loc = r.headers && typeof r.headers.get === 'function' ? r.headers.get('location') : null;
        if (!loc) return { ok: false, reason: 'redirect-unreadable' };
        try { url = new URL(loc, v.url.href).href; } catch (e) { return { ok: false, reason: 'bad-redirect' }; }
        continue;                                  // the next loop iteration validates the target before any request
      }
      if (!r.ok) return { ok: false, reason: 'http-' + r.status };
      const ct = (r.headers && r.headers.get && r.headers.get('content-type')) || '';
      if (ct && !/text\/|xml|json/i.test(ct)) return { ok: false, reason: 'content-type' };
      const text = await readBounded(r, MAX_BYTES);
      return text == null ? { ok: false, reason: 'no-stream' } : { ok: true, text, url: v.url.href };
    }
    return { ok: false, reason: 'too-many-redirects' };
  } finally { clearTimeout(timer); }
}

function urlVariants(raw) {
  const out = [];
  let u;
  try { u = new URL(raw); } catch (e) { return out; }
  const hosts = [u.hostname];
  if (!parseIPv4(u.hostname) && !u.hostname.startsWith('[')) {
    hosts.push(u.hostname.startsWith('www.') ? u.hostname.slice(4) : 'www.' + u.hostname);
  }
  for (const proto of ['https:', 'http:']) {
    for (const h of hosts) {
      const c = new URL(u.href);
      c.protocol = proto; c.hostname = h;
      if (c.href !== u.href && !out.includes(c.href)) out.push(c.href);
    }
  }
  return out.slice(0, 3);
}

async function getPage(url) {
  const first = await safeGet(url);
  if (first.ok || first.reason !== 'redirect-unreadable') return first;
  for (const alt of urlVariants(url)) {            // each alternative is validated again inside safeGet
    const r = await safeGet(alt);
    if (r.ok) return r;
  }
  return first;
}

/* =========================================================================
 * Email extraction
 * ========================================================================= */

const FREE = /(^|\.)(gmail|yahoo|hotmail|outlook|live|icloud|proton|protonmail)\./i;
const PREFERRED = /^(info|contact|hello|sales|admissions?|enquir(y|ies)|inquir(y|ies)|office|support|admin|team|mail)$/i;
const BAD_LOCAL = /^(you|your|yourname|name|email|user|username|test|example|someone|john|jane|firstname|lastname|noreply|no-reply|donotreply)$/i;
const BAD_DOMAIN = /(^|\.)(example\.com|domain\.com|email\.com|yourdomain\.com|sentry\.io|sentry-next\.wixpress\.com|wixpress\.com|sentry\.wixpress\.com|godaddy\.com|schema\.org|w3\.org|wordpress\.org|wp\.com|gravatar\.com)$/i;
const FILE_EXT = /\.(png|jpe?g|gif|webp|svg|ico|css|js|woff2?|ttf|eot|map|mp4|pdf|avif)$/i;

function decodeCf(hex) {
  const k = parseInt(hex.slice(0, 2), 16);
  let s = '';
  for (let i = 2; i < hex.length; i += 2) s += String.fromCharCode(parseInt(hex.slice(i, i + 2), 16) ^ k);
  return s;
}

function valid(e) {
  const m = e.match(/^([^@]+)@(.+)$/);
  if (!m) return false;
  const [, local, domain] = m;
  if (local.length > 64 || domain.length > 100 || domain.includes('..')) return false;
  if (FILE_EXT.test(e) || BAD_LOCAL.test(local) || BAD_DOMAIN.test(domain)) return false;
  if (/^\d+x$/.test(local)) return false;
  return /^[a-z0-9.\-]+\.[a-z]{2,24}$/.test(domain);
}

function extract(raw) {
  const found = new Set();
  for (const m of raw.matchAll(/data-cfemail=["']([0-9a-f]+)["']/gi)) { try { found.add(decodeCf(m[1])); } catch (e) { /* skip */ } }
  for (const m of raw.matchAll(/email-protection#([0-9a-f]+)/gi)) { try { found.add(decodeCf(m[1])); } catch (e) { /* skip */ } }
  let t = raw.replace(/&#0*64;|&commat;|%40|\\u0040/gi, '@').replace(/&#0*46;|&period;/gi, '.')
    .replace(/\s*[\[\(\{]\s*at\s*[\]\)\}]\s*/gi, '@').replace(/\s*[\[\(\{]\s*dot\s*[\]\)\}]\s*/gi, '.');
  for (const m of t.matchAll(/mailto:([^"'?\s<>&]+)/gi)) { try { found.add(decodeURIComponent(m[1])); } catch (e) { found.add(m[1]); } }
  for (const m of t.matchAll(/[a-z0-9._%+\-]{1,64}@[a-z0-9\-]+(?:\.[a-z0-9\-]+)*\.[a-z]{2,24}/gi)) found.add(m[0]);
  return [...found]
    .map(e => e.trim().toLowerCase().replace(/^(u003e|u003c|u002f|x3e|x3c)+/, '').replace(/^[.\-_]+|[.\-_]+$/g, ''))
    .filter(valid);
}

function score(email, host) {
  const [local, domain] = email.split('@');
  const h = host.replace(/^www\./, '');
  let s = 0;
  if (h === domain || h.endsWith('.' + domain) || domain.endsWith('.' + h)) s += 3;
  if (PREFERRED.test(local)) s += 2;
  if (FREE.test(domain)) s += 1;
  return s;
}

// Same-site contact/about links; every candidate is validated again before it is fetched.
function contactLinks(html, base) {
  const out = new Set();
  let origin;
  try { origin = new URL(base).origin; } catch (e) { return []; }
  for (const m of html.matchAll(/href=["']([^"'#]+)["']/gi)) {
    if (!/contact|about|reach|touch|enquir|inquir|support|connect/i.test(m[1])) continue;
    try {
      const u = new URL(m[1], base);
      if (u.origin === origin && validatePublicUrl(u.href).ok && !FILE_EXT.test(u.pathname)) out.add(u.href.split('#')[0]);
    } catch (e) { /* skip */ }
    if (out.size >= 2) break;
  }
  return [...out];
}

async function findEmails(url) {
  const start = validatePublicUrl(url);
  if (!start.ok) return { ok: false, error: 'blocked url' };

  const home = await getPage(start.url.href);
  if (!home.ok) return { ok: false, error: 'site did not respond (' + home.reason + ')' };
  const host = new URL(home.url).hostname;
  let emails = extract(home.text);
  let pages = 1;
  if (!emails.length) {
    for (const link of contactLinks(home.text, home.url)) {
      const p = await safeGet(link);
      pages++;
      if (p.ok) { emails = extract(p.text); if (emails.length) break; }
    }
  }
  emails = [...new Set(emails)].sort((a, b) => score(b, host) - score(a, host)).slice(0, 3);
  return { ok: true, emails, pages };
}

/* Server-verified account access. No offline license-key fallback. */
let cachedAccess = null;
let pendingCheck = null;
async function accessApi(path, body) {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 12000);
  try {
    const r = await fetch(HC_ACCESS_ORIGIN + path, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      credentials: 'omit', cache: 'no-store', signal: controller.signal,
      body: JSON.stringify(body),
    });
    if (r.status === 401) return { ok: false, state: 'signedout' };
    if (!r.ok) return { ok: false, state: 'offline' };
    const result = await r.json();
    return result;
  } catch { return { ok: false, state: 'offline' }; }
  finally { clearTimeout(timeout); }
}
async function licenseStatus(force = false) {
  if (!force && cachedAccess && Date.now() - cachedAccess.at < 2500) return cachedAccess.value;
  if (pendingCheck) return pendingCheck;
  pendingCheck = (async () => {
    const { hcSession } = await chrome.storage.local.get('hcSession');
    if (!hcSession) return { ok: false, state: 'signedout' };
    const result = await accessApi('/api/extension/check', { token: hcSession, device: true });
    // Do not let a late response restore access after local sign-out or an account switch.
    const current = (await chrome.storage.local.get('hcSession')).hcSession;
    if (current !== hcSession) return { ok: false, state: 'signedout' };
    if (result.state === 'signedout') await chrome.storage.local.remove('hcSession');
    const clean = {
      ok: result.ok === true && result.state === 'approved',
      state: result.state || 'offline', email: String(result.email || ''),
      name: String(result.name || ''), expires: Number(result.expires || 0),
      vendor: 'Haseeb Crafts', canSetup: false, notification: result.notification || null,
    };
    const before = (await chrome.storage.local.get('hcAccess')).hcAccess;
    if (!before || before.state !== clean.state || before.email !== clean.email) {
      await chrome.storage.local.set({ hcAccess: clean });
      if (clean.ok && before?.state !== 'approved' && chrome.notifications) {
        chrome.notifications.create('hc-approved', {type:'basic', iconUrl:'icons/icon128.png', title:'Haseeb Crafts — Access approved', message:'Your Maps Lead Finder access is approved. The Maps panel is ready.'}).catch(()=>{});
      }
      const tabs = await chrome.tabs.query({url:['https://www.google.com/maps*','https://www.google.com.pk/maps*','https://maps.google.com/*']});
      for(const tab of tabs) chrome.tabs.sendMessage(tab.id,{type:'hc-access-updated',access:clean}).catch(()=>{});
    }
    cachedAccess = { at: Date.now(), value: clean };
    return clean;
  })();
  try { return await pendingCheck; } finally { pendingCheck = null; }
}
async function beginSignIn() {
  // The raw secret never goes into a browser URL. Only its SHA-256 identifier does.
  const saved = (await chrome.storage.local.get('hcSession')).hcSession;
  const secret = typeof saved === 'string' && /^[a-f0-9]{64}$/.test(saved) ? saved : Array.from(crypto.getRandomValues(new Uint8Array(32)), b => b.toString(16).padStart(2, '0')).join('');
  const pair = Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256', new TextEncoder().encode(secret))), b=>b.toString(16).padStart(2,'0')).join('');
  await chrome.storage.local.set({ hcSession: secret, hcAccess:{ok:false,state:'linking'} });
  cachedAccess = null;
  const url = new URL(HC_ACCESS_ORIGIN + '/');
  url.searchParams.set('pair', pair);
  await chrome.tabs.create({ url: url.href });
  return { ok: true };
}

async function signOut() {
  const { hcSession } = await chrome.storage.local.get('hcSession');
  await chrome.storage.local.remove(['hcSession', 'hcPending', 'hcAccess', 'license', 'ownerSetup', 'statusCache']);
  cachedAccess = null;
  if (hcSession) await accessApi('/api/extension/logout', { token: hcSession, device: true });
  return { ok: false, state: 'signedout' };
}
chrome.runtime.onMessageExternal.addListener((msg, sender, send) => {
  if (!sender.url || new URL(sender.url).origin !== HC_ACCESS_ORIGIN || msg?.type !== 'hc-connect') return;
  (async () => {
    const { hcPending } = await chrome.storage.local.get('hcPending');
    if (!hcPending || hcPending.expires < Date.now() || msg.challenge !== hcPending.challenge
      || typeof msg.token !== 'string' || !/^[a-f0-9]{64}$/.test(msg.token)) {
      return send({ ok: false, error: 'Sign-in link expired. Start again from the extension popup.' });
    }
    const access = await accessApi('/api/extension/check', { token: msg.token });
    if (!access.ok || access.state !== 'approved') return send({ ok: false, error: 'Account is not approved or cannot be verified online.' });
    await chrome.storage.local.set({ hcSession: msg.token });
    await chrome.storage.local.remove('hcPending'); cachedAccess = null;
    send({ ok: true });
  })().catch(() => send({ ok: false, error: 'Could not connect. Please retry.' }));
  return true;
});
chrome.runtime.onMessage.addListener((msg, _sender, send) => {
  if (!msg) return;
  if (msg.type === 'lf-license') {
    licenseStatus(!!msg.force).then(send).catch(() => send({ ok: false, state: 'offline' })); return true;
  }
  if (msg.type === 'hc-signin') {
    beginSignIn().then(send).catch(() => send({ ok: false, error: 'Could not open sign-in.' })); return true;
  }
  if (msg.type === 'hc-portal') {
    chrome.tabs.create({ url: HC_ACCESS_ORIGIN + '/' }).then(() => send({ ok: true })); return true;
  }
  if (msg.type === 'lf-deactivate') {
    signOut().then(send).catch(() => send({ ok: false, state: 'signedout' })); return true;
  }
  if (msg.type === 'lf-find-email') {
    licenseStatus().then(st => st.ok ? findEmails(msg.url) : { ok: false, error: 'Account access required' })
      .then(send).catch(e => send({ ok: false, error: String(e) })); return true;
  }
});

// MV3 service workers sleep; alarms keep linked accounts checked when the popup is closed.
if (chrome.alarms) {
  chrome.alarms.create('hc-access-check', {periodInMinutes:0.5});
  chrome.alarms.onAlarm.addListener(alarm=>{ if(alarm.name==='hc-access-check') licenseStatus(true).catch(()=>{}); });
}
