// Background service worker:
//  1) license checks (signature, account, expiry, remote ON/OFF) and
//  2) public-email discovery on business websites, with strict URL validation.
importScripts('license-public.js');

/* =========================================================================
 * Public URL validation (used for every page we fetch: homepage, contact
 * pages and every redirect hop)
 * ========================================================================= */

function parseIPv4(h) {
  const m = h.match(/^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/);
  if (!m) return null;
  const o = m.slice(1).map(Number);
  return o.every(n => n <= 255) ? o : null;
}

function nonPublicIPv4(o) {
  const [a, b, c] = o;
  return a === 0 || a === 10 || a === 127 ||
    (a === 100 && b >= 64 && b <= 127) ||        // carrier-grade NAT
    (a === 169 && b === 254) ||                  // link-local / cloud metadata
    (a === 172 && b >= 16 && b <= 31) ||
    (a === 192 && b === 0 && (c === 0 || c === 2)) ||
    (a === 192 && b === 168) ||
    (a === 198 && (b === 18 || b === 19)) ||
    (a === 198 && b === 51 && c === 100) ||
    (a === 203 && b === 0 && c === 113) ||
    a >= 224;                                    // multicast, reserved, broadcast
}

function parseIPv6(h) {
  if (h.includes('%')) return null;              // zone ids are never public
  const m4 = h.match(/^(.*:)(\d{1,3}(?:\.\d{1,3}){3})$/);
  if (m4) {
    const o = parseIPv4(m4[2]);
    if (!o) return null;
    h = m4[1] + ((o[0] << 8) | o[1]).toString(16) + ':' + ((o[2] << 8) | o[3]).toString(16);
  }
  const parts = h.split('::');
  if (parts.length > 2) return null;
  const left = parts[0] ? parts[0].split(':') : [];
  const right = parts.length === 2 && parts[1] ? parts[1].split(':') : [];
  if (parts.length === 1 && left.length !== 8) return null;
  if (parts.length === 2 && left.length + right.length > 7) return null;
  const fill = parts.length === 2 ? new Array(8 - left.length - right.length).fill('0') : [];
  const all = [...left, ...fill, ...right];
  if (all.length !== 8) return null;
  const nums = all.map(x => (/^[0-9a-f]{1,4}$/i.test(x) ? parseInt(x, 16) : NaN));
  return nums.some(Number.isNaN) ? null : nums;
}

// Allow-list: only global unicast 2000::/3, minus special-purpose ranges. This rejects ::1, ::, fe80::/10,
// fc00::/7, ff00::/8, ::ffff:a.b.c.d (IPv4-mapped), 64:ff9b::/96 (NAT64) and more.
function publicIPv6(n) {
  if ((n[0] & 0xe000) !== 0x2000) return false;
  if (n[0] === 0x2001 && n[1] < 0x200) return false;                 // 2001::/23 (Teredo, protocol assignments)
  if (n[0] === 0x2001 && n[1] === 0x0db8) return false;              // documentation
  if (n[0] === 0x2002) return false;                                 // 6to4
  if (n[0] === 0x3fff && (n[1] & 0xf000) === 0) return false;        // documentation
  return true;
}

const BLOCKED_SUFFIX = /\.(localhost|local|internal|intranet|lan|home|corp|private|test|example|invalid|localdomain|home\.arpa)$/i;

// Returns { ok: true, url: URL } or { ok: false, reason }.
// NOTE: this checks the text of the URL only. It cannot detect a public-looking hostname whose DNS record points to
// a private address (DNS rebinding); the extension has no API to inspect the resolved address.
function validatePublicUrl(raw) {
  const text = String(raw == null ? '' : raw);
  if (!text || text.length > 2048) return { ok: false, reason: 'invalid-url' };
  let u;
  try { u = new URL(text); } catch (e) { return { ok: false, reason: 'invalid-url' }; }
  if (u.protocol !== 'http:' && u.protocol !== 'https:') return { ok: false, reason: 'scheme' };
  if (u.username || u.password) return { ok: false, reason: 'credentials' };
  if (u.port && u.port !== '80' && u.port !== '443') return { ok: false, reason: 'port' };
  const h = u.hostname.toLowerCase().replace(/\.$/, '');
  if (!h) return { ok: false, reason: 'invalid-url' };
  if (h.startsWith('[')) {
    const n = parseIPv6(h.slice(1, -1));
    return n && publicIPv6(n) ? { ok: true, url: u } : { ok: false, reason: 'non-public-ip' };
  }
  const v4 = parseIPv4(h);
  if (v4) return nonPublicIPv4(v4) ? { ok: false, reason: 'non-public-ip' } : { ok: true, url: u };
  if (/^[\d.]+$/.test(h) || !/^[a-z0-9._-]+$/.test(h)) return { ok: false, reason: 'invalid-host' };
  if (!h.includes('.') || h === 'localhost' || BLOCKED_SUFFIX.test(h)) return { ok: false, reason: 'non-public-host' };
  return { ok: true, url: u };
}

/* =========================================================================
 * Fetching websites
 * Redirects are NOT followed automatically. In an extension service worker a fetch with redirect:'manual'
 * returns an "opaqueredirect" response whose Location is not readable, so a redirect target cannot be
 * validated. When the Location is unreadable we fail safely and only try a few predictable, individually
 * validated alternatives (https, www on/off). Sites that redirect elsewhere (e.g. to /en/) are skipped.
 * ========================================================================= */

const TIMEOUT = 9000;
const MAX_HOPS = 3;
const MAX_BYTES = 1500000;   // pages are read only up to this size

// Reads a response body up to maxBytes and stops downloading beyond that. Returns text or null.
async function readBounded(resp, maxBytes) {
  if (!resp.body || typeof resp.body.getReader !== 'function') return null;   // can't bound it: fail safely
  const reader = resp.body.getReader();
  const chunks = [];
  let total = 0;
  for (;;) {
    const { done, value } = await reader.read();
    if (done) break;
    total += value.byteLength;
    if (total > maxBytes) {
      chunks.push(value.subarray(0, value.byteLength - (total - maxBytes)));
      try { await reader.cancel(); } catch (e) { /* ignore */ }
      break;
    }
    chunks.push(value);
  }
  const out = new Uint8Array(chunks.reduce((n, c) => n + c.byteLength, 0));
  let off = 0;
  for (const c of chunks) { out.set(c, off); off += c.byteLength; }
  return new TextDecoder('utf-8').decode(out);
}

async function safeGet(startUrl) {
  const ctl = new AbortController();
  const timer = setTimeout(() => ctl.abort(), TIMEOUT);
  try {
    let url = startUrl;
    for (let hop = 0; hop <= MAX_HOPS; hop++) {
      const v = validatePublicUrl(url);
      if (!v.ok) return { ok: false, reason: 'blocked-url' };
      let r;
      try {
        r = await fetch(v.url.href, { signal: ctl.signal, redirect: 'manual', credentials: 'omit', cache: 'no-store' });
      } catch (e) { return { ok: false, reason: 'network' }; }
      if (r.type === 'opaqueredirect' || (r.status >= 300 && r.status < 400)) {
        const loc = r.headers && typeof r.headers.get === 'function' ? r.headers.get('location') : null;
        if (!loc) return { ok: false, reason: 'redirect-unreadable' };
        try { url = new URL(loc, v.url.href).href; } catch (e) { return { ok: false, reason: 'bad-redirect' }; }
        continue;                                  // the next loop iteration validates the target before any request
      }
      if (!r.ok) return { ok: false, reason: 'http-' + r.status };
      const ct = (r.headers && r.headers.get && r.headers.get('content-type')) || '';
      if (ct && !/text\/|xml|json/i.test(ct)) return { ok: false, reason: 'content-type' };
      const text = await readBounded(r, MAX_BYTES);
      return text == null ? { ok: false, reason: 'no-stream' } : { ok: true, text, url: v.url.href };
    }
    return { ok: false, reason: 'too-many-redirects' };
  } finally { clearTimeout(timer); }
}

function urlVariants(raw) {
  const out = [];
  let u;
  try { u = new URL(raw); } catch (e) { return out; }
  const hosts = [u.hostname];
  if (!parseIPv4(u.hostname) && !u.hostname.startsWith('[')) {
    hosts.push(u.hostname.startsWith('www.') ? u.hostname.slice(4) : 'www.' + u.hostname);
  }
  for (const proto of ['https:', 'http:']) {
    for (const h of hosts) {
      const c = new URL(u.href);
      c.protocol = proto; c.hostname = h;
      if (c.href !== u.href && !out.includes(c.href)) out.push(c.href);
    }
  }
  return out.slice(0, 3);
}

async function getPage(url) {
  const first = await safeGet(url);
  if (first.ok || first.reason !== 'redirect-unreadable') return first;
  for (const alt of urlVariants(url)) {            // each alternative is validated again inside safeGet
    const r = await safeGet(alt);
    if (r.ok) return r;
  }
  return first;
}

/* =========================================================================
 * Email extraction
 * ========================================================================= */

const FREE = /(^|\.)(gmail|yahoo|hotmail|outlook|live|icloud|proton|protonmail)\./i;
const PREFERRED = /^(info|contact|hello|sales|admissions?|enquir(y|ies)|inquir(y|ies)|office|support|admin|team|mail)$/i;
const BAD_LOCAL = /^(you|your|yourname|name|email|user|username|test|example|someone|john|jane|firstname|lastname|noreply|no-reply|donotreply)$/i;
const BAD_DOMAIN = /(^|\.)(example\.com|domain\.com|email\.com|yourdomain\.com|sentry\.io|sentry-next\.wixpress\.com|wixpress\.com|sentry\.wixpress\.com|godaddy\.com|schema\.org|w3\.org|wordpress\.org|wp\.com|gravatar\.com)$/i;
const FILE_EXT = /\.(png|jpe?g|gif|webp|svg|ico|css|js|woff2?|ttf|eot|map|mp4|pdf|avif)$/i;

function decodeCf(hex) {
  const k = parseInt(hex.slice(0, 2), 16);
  let s = '';
  for (let i = 2; i < hex.length; i += 2) s += String.fromCharCode(parseInt(hex.slice(i, i + 2), 16) ^ k);
  return s;
}

function valid(e) {
  const m = e.match(/^([^@]+)@(.+)$/);
  if (!m) return false;
  const [, local, domain] = m;
  if (local.length > 64 || domain.length > 100 || domain.includes('..')) return false;
  if (FILE_EXT.test(e) || BAD_LOCAL.test(local) || BAD_DOMAIN.test(domain)) return false;
  if (/^\d+x$/.test(local)) return false;
  return /^[a-z0-9.\-]+\.[a-z]{2,24}$/.test(domain);
}

function extract(raw) {
  const found = new Set();
  for (const m of raw.matchAll(/data-cfemail=["']([0-9a-f]+)["']/gi)) { try { found.add(decodeCf(m[1])); } catch (e) { /* skip */ } }
  for (const m of raw.matchAll(/email-protection#([0-9a-f]+)/gi)) { try { found.add(decodeCf(m[1])); } catch (e) { /* skip */ } }
  let t = raw.replace(/&#0*64;|&commat;|%40|\\u0040/gi, '@').replace(/&#0*46;|&period;/gi, '.')
    .replace(/\s*[\[\(\{]\s*at\s*[\]\)\}]\s*/gi, '@').replace(/\s*[\[\(\{]\s*dot\s*[\]\)\}]\s*/gi, '.');
  for (const m of t.matchAll(/mailto:([^"'?\s<>&]+)/gi)) { try { found.add(decodeURIComponent(m[1])); } catch (e) { found.add(m[1]); } }
  for (const m of t.matchAll(/[a-z0-9._%+\-]{1,64}@[a-z0-9\-]+(?:\.[a-z0-9\-]+)*\.[a-z]{2,24}/gi)) found.add(m[0]);
  return [...found]
    .map(e => e.trim().toLowerCase().replace(/^(u003e|u003c|u002f|x3e|x3c)+/, '').replace(/^[.\-_]+|[.\-_]+$/g, ''))
    .filter(valid);
}

function score(email, host) {
  const [local, domain] = email.split('@');
  const h = host.replace(/^www\./, '');
  let s = 0;
  if (h === domain || h.endsWith('.' + domain) || domain.endsWith('.' + h)) s += 3;
  if (PREFERRED.test(local)) s += 2;
  if (FREE.test(domain)) s += 1;
  return s;
}

// Same-site contact/about links; every candidate is validated again before it is fetched.
function contactLinks(html, base) {
  const out = new Set();
  let origin;
  try { origin = new URL(base).origin; } catch (e) { return []; }
  for (const m of html.matchAll(/href=["']([^"'#]+)["']/gi)) {
    if (!/contact|about|reach|touch|enquir|inquir|support|connect/i.test(m[1])) continue;
    try {
      const u = new URL(m[1], base);
      if (u.origin === origin && validatePublicUrl(u.href).ok && !FILE_EXT.test(u.pathname)) out.add(u.href.split('#')[0]);
    } catch (e) { /* skip */ }
    if (out.size >= 2) break;
  }
  return [...out];
}

async function findEmails(url) {
  const start = validatePublicUrl(url);
  if (!start.ok) return { ok: false, error: 'blocked url' };

  const home = await getPage(start.url.href);
  if (!home.ok) return { ok: false, error: 'site did not respond (' + home.reason + ')' };
  const host = new URL(home.url).hostname;
  let emails = extract(home.text);
  let pages = 1;
  if (!emails.length) {
    for (const link of contactLinks(home.text, home.url)) {
      const p = await safeGet(link);
      pages++;
      if (p.ok) { emails = extract(p.text); if (emails.length) break; }
    }
  }
  emails = [...new Set(emails)].sort((a, b) => score(b, host) - score(a, host)).slice(0, 3);
  return { ok: true, emails, pages };
}

/* =========================================================================
 * License
 * Modes (license-public.js):
 *   LF_MODE = "release"      (default) a valid public key MUST be baked into license-public.js, otherwise the
 *                            copy stays locked with "License configuration required".
 *   LF_MODE = "development"  owner-only. Without a baked key the owner may paste a public key into the panel.
 * No private key is ever needed or accepted here; a key containing private material is rejected.
 * ========================================================================= */

function b64uDecode(str) {
  str = str.replace(/-/g, '+').replace(/_/g, '/');
  while (str.length % 4) str += '=';
  const bin = atob(str);
  const out = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
  return out;
}

function profileEmail() {
  return new Promise(resolve => {
    try {
      chrome.identity.getProfileUserInfo({ accountStatus: 'ANY' }, info => {
        resolve(((info && info.email) || '').trim().toLowerCase());
      });
    } catch (e) { resolve(''); }
  });
}

function maskEmail(e) {
  const [a, d] = String(e).split('@');
  return (a ? a[0] : '') + '***@' + (d || '');
}

const currentMode = () => (globalThis.LF_MODE === 'development' ? 'development' : 'release');

// Accepts only a well-formed EC P-256 PUBLIC key. Anything containing private components is refused.
async function validPublicKeyJwk(jwk) {
  try {
    if (!jwk || typeof jwk !== 'object') return null;
    if (['d', 'p', 'q', 'dp', 'dq', 'qi', 'k'].some(f => f in jwk)) return null;
    if (jwk.kty !== 'EC' || jwk.crv !== 'P-256' || typeof jwk.x !== 'string' || typeof jwk.y !== 'string') return null;
    const clean = { kty: 'EC', crv: 'P-256', x: jwk.x, y: jwk.y };
    await crypto.subtle.importKey('jwk', clean, { name: 'ECDSA', namedCurve: 'P-256' }, false, ['verify']);
    return clean;
  } catch (e) { return null; }
}

function cleanStatusUrl(raw) {
  const s = String(raw == null ? '' : raw).trim();
  if (!s) return '';
  if (!/^https:\/\//i.test(s)) return null;
  return validatePublicUrl(s).ok ? s : null;
}

// Resolves where the verification key comes from. Returns { pub, vendor, statusUrl, mode } or { error, mode, vendor }.
async function getSetup() {
  const mode = currentMode();
  const vendor = String(globalThis.LF_VENDOR || '');
  const statusUrl = cleanStatusUrl(globalThis.LF_STATUS_URL);
  if (globalThis.LF_PUBLIC_KEY != null) {
    const pub = await validPublicKeyJwk(globalThis.LF_PUBLIC_KEY);
    if (!pub || statusUrl === null) return { error: 'config', mode, vendor, canSetup: false };
    return { pub, vendor, statusUrl, mode, canSetup: false };    // a key baked into license-public.js always wins
  }
  // No key is baked in, so the owner can finish setup from the panel (this is never possible once a key is baked in).
  // The copy stays locked until a valid PUBLIC key has been saved.
  const { ownerSetup } = await chrome.storage.local.get('ownerSetup');
  const pub = ownerSetup && (await validPublicKeyJwk(ownerSetup.pub));
  const su = ownerSetup ? cleanStatusUrl(ownerSetup.statusUrl) : '';
  if (pub && su !== null) return { pub, vendor: ownerSetup.vendor || '', statusUrl: su, mode, owner: true, canSetup: true };
  return { error: mode === 'development' ? 'nokey' : 'config', mode, vendor, canSetup: true };
}

// Returns the signed payload if the signature is valid, otherwise null.
async function verifyToken(token, pub) {
  try {
    const [p, sig] = String(token || '').trim().split('.');
    if (!p || !sig || !pub) return null;
    const key = await crypto.subtle.importKey('jwk', pub, { name: 'ECDSA', namedCurve: 'P-256' }, false, ['verify']);
    const ok = await crypto.subtle.verify({ name: 'ECDSA', hash: 'SHA-256' }, key, b64uDecode(sig), b64uDecode(p));
    if (!ok) return null;
    return JSON.parse(new TextDecoder().decode(b64uDecode(p)));
  } catch (e) { return null; }
}

// Signature + payload structure. Expiry x: 0 / missing = no expiry, otherwise a positive integer (ms since epoch).
async function parseLicense(license, pub) {
  const p = await verifyToken(license, pub);
  if (!p || typeof p !== 'object' || Array.isArray(p) || p.v !== 1) return null;
  if (typeof p.e !== 'string' || p.e.length > 254 || !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(p.e)) return null;
  const x = p.x === undefined || p.x === null ? 0 : p.x;
  if (x !== 0 && !(Number.isSafeInteger(x) && x > 0 && x < 4102444800000)) return null;   // must be before year 2100
  if (p.i !== undefined && !(typeof p.i === 'string' && /^[A-Za-z0-9_-]{1,64}$/.test(p.i))) return null;
  if (p.n !== undefined && !(typeof p.n === 'string' && p.n.length <= 120)) return null;
  return { e: p.e.toLowerCase(), x, i: p.i, n: p.n || '' };
}

/* ---------- remote ON/OFF: a signed status file the owner hosts anywhere ---------- */
const STATUS_TTL = 10 * 60 * 1000;      // re-check at most every 10 minutes
const STATUS_RETRY = 60 * 1000;         // after a failed try, wait a minute
const STATUS_GRACE = 72 * 3600 * 1000;  // allowed offline time after the last good check
const STATUS_MAX_BYTES = 200000;

async function fetchStatus(setup) {
  const ctl = new AbortController();
  const t = setTimeout(() => ctl.abort(), 6000);
  try {
    const u = new URL(setup.statusUrl);
    u.searchParams.set('_', Date.now());
    // The status URL is fixed in the owner's license-public.js (not attacker-controlled), so ordinary redirects
    // (e.g. www or http to https) are allowed; the signature is what makes the content trustworthy.
    const r = await fetch(u.href, { signal: ctl.signal, cache: 'no-store', credentials: 'omit' });
    if (!r.ok) return null;
    const text = await readBounded(r, STATUS_MAX_BYTES);
    if (text == null) return null;
    const p = await verifyToken(JSON.parse(text).token, setup.pub);
    if (!p || !Array.isArray(p.disabled)) return null;
    return { seq: Number(p.seq) || 0, disabled: p.disabled.map(String) };
  } catch (e) { return null; } finally { clearTimeout(t); }
}

// Returns { list } with the disabled license ids, or { list: null } when it can't be verified.
async function getRevocations(setup) {
  if (!setup.statusUrl) return { list: [] };
  const now = Date.now();
  const { statusCache: c } = await chrome.storage.local.get('statusCache');
  const same = c && c.url === setup.statusUrl;
  if (same && now - c.fetchedAt < STATUS_TTL) return { list: c.disabled };
  if (same && c.lastTry && now - c.lastTry < STATUS_RETRY) return { list: now - c.fetchedAt < STATUS_GRACE ? c.disabled : null };
  const got = await fetchStatus(setup);
  if (got && (!same || got.seq >= (c.seq || 0))) {
    await chrome.storage.local.set({ statusCache: { url: setup.statusUrl, seq: got.seq, disabled: got.disabled, fetchedAt: now } });
    return { list: got.disabled };
  }
  const base = same ? c : { url: setup.statusUrl, seq: 0, disabled: [], fetchedAt: 0 };
  await chrome.storage.local.set({ statusCache: { ...base, lastTry: now } });
  return { list: now - base.fetchedAt < STATUS_GRACE ? base.disabled : null };
}

// Full check of ONE license key against the Chrome account. Used both for the stored license and, before anything
// is saved, for a key the user is trying to activate.
async function evaluateLicense(license, setup, email) {
  const base = { email, vendor: setup.vendor, mode: setup.mode, owner: !!setup.owner, canSetup: !!setup.canSetup };
  if (!email) return { ...base, ok: false, state: 'noemail', email: '' };
  const p = await parseLicense(license, setup.pub);
  if (!p) return { ...base, ok: false, state: 'invalid' };
  if (p.e !== email) return { ...base, ok: false, state: 'mismatch', licensedTo: maskEmail(p.e) };
  if (p.x && Date.now() > p.x) return { ...base, ok: false, state: 'expired', expires: p.x };
  const rev = await getRevocations(setup);
  if (!rev.list) return { ...base, ok: false, state: 'offline' };
  if (p.i && rev.list.includes(p.i)) return { ...base, ok: false, state: 'disabled' };
  return { ...base, ok: true, state: 'licensed', name: p.n, expires: p.x };
}

async function licenseStatus() {
  const setup = await getSetup();
  const email = await profileEmail();
  if (setup.error) return { ok: false, state: setup.error, email, vendor: setup.vendor || '', mode: setup.mode, canSetup: !!setup.canSetup };
  const { license } = await chrome.storage.local.get('license');
  if (!license) return { ok: false, state: email ? 'unlicensed' : 'noemail', email, vendor: setup.vendor, mode: setup.mode, owner: !!setup.owner, canSetup: !!setup.canSetup };
  return evaluateLicense(license, setup, email);
}

// Owner setup: accepts the text of license-public.js (or the bare key JSON) when no key is baked in. PUBLIC key only.
async function saveSetup(text) {
  if (globalThis.LF_PUBLIC_KEY != null) return licenseStatus();   // a baked-in key can never be overridden from the panel
  const t = String(text || '');
  let pub = null, vendor = '', statusUrl = '';
  try { const m = t.match(/\{[^{}]*"kty"[^{}]*\}/); if (m) pub = JSON.parse(m[0]); } catch (e) { pub = null; }
  try { const v = t.match(/LF_VENDOR\s*=\s*("(?:[^"\\]|\\.)*")/); if (v) vendor = JSON.parse(v[1]); } catch (e) { vendor = ''; }
  try { const v = t.match(/LF_STATUS_URL\s*=\s*("(?:[^"\\]|\\.)*")/); if (v) statusUrl = JSON.parse(v[1]); } catch (e) { statusUrl = ''; }
  const clean = await validPublicKeyJwk(pub);
  const su = cleanStatusUrl(statusUrl);
  if (!clean || su === null) return { ok: false, state: 'badsetup', mode: 'development' };
  await chrome.storage.local.set({ ownerSetup: { pub: clean, vendor, statusUrl: su } });
  return licenseStatus();
}

chrome.runtime.onMessage.addListener((msg, _sender, send) => {
  if (!msg) return;
  if (msg.type === 'lf-license') {
    licenseStatus().then(send).catch(() => send({ ok: false, state: 'error' }));
    return true;
  }
  if (msg.type === 'lf-setup') {
    saveSetup(msg.text).then(send).catch(() => send({ ok: false, state: 'error' }));
    return true;
  }
  if (msg.type === 'lf-deactivate') {
    chrome.storage.local.remove(['license']).then(() => licenseStatus()).then(send).catch(() => send({ ok: false, state: 'error' }));
    return true;
  }
  if (msg.type === 'lf-clear-setup') {
    (async () => {
      if (globalThis.LF_PUBLIC_KEY == null) await chrome.storage.local.remove(['ownerSetup', 'license', 'statusCache']);
      send(await licenseStatus());
    })().catch(() => send({ ok: false, state: 'error' }));
    return true;
  }
  if (msg.type === 'lf-activate') {
    (async () => {
      const setup = await getSetup();
      if (setup.error) return send({ ok: false, state: setup.error, vendor: setup.vendor || '', mode: setup.mode, canSetup: !!setup.canSetup });
      const email = await profileEmail();
      const key = String(msg.key || '').trim();
      const result = await evaluateLicense(key, setup, email);   // everything is verified BEFORE anything is saved
      if (!result.ok) return send(result);                        // the existing license is left untouched
      await chrome.storage.local.set({ license: key });
      send(result);
    })().catch(() => send({ ok: false, state: 'error' }));
    return true;
  }
  if (msg.type === 'lf-find-email') {
    licenseStatus()
      .then(st => (st.ok ? findEmails(msg.url) : { ok: false, error: 'not licensed' }))
      .then(send)
      .catch(e => send({ ok: false, error: String(e) }));
    return true; // async response
  }
});
