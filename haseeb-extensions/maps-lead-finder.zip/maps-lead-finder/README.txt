Maps Lead Finder v2.2.0 — Haseeb Crafts

1. Extract this ZIP.
2. Open chrome://extensions and enable Developer mode.
3. Select Load unpacked and choose maps-lead-finder.
4. Click Sign in in the extension popup.
5. Sign in with ChatGPT, submit your name/contact and consent, and wait for Haseeb Crafts approval.
6. The browser links automatically when you sign in. Owner approval unlocks it without another Connect click.
7. Open Google Maps. The panel updates automatically after approval.

No license key or license-public.js setup is used in v2.
Internet verification is required. Access is rechecked on Start, email requests and every 5 seconds in an open Maps panel.
A connected session lasts up to 30 days, after which sign in again.
Sign out removes this extension's session; your leads stay in this browser.
Website sign-out and extension sign-out are separate. Use Sign out in the extension to disconnect it.

Privacy: lead data is stored locally. The access service stores your verified account email, submitted name/contact,
access status, expiry, download-request clicks and access-session records. Download clicks do not prove a completed download.
Approval can be blocked or expired by the owner. A locally modified extension cannot be made tamper-proof.

Existing users: back up leads before replacing an unpacked installation. Keep the same folder path when updating
so Chrome can retain the same extension identity and local data. Old signed-license versions are not controlled by v2 approval.

Approval notifications appear in the portal and, if allowed by Chrome/Windows, as a desktop notification. Background checks run every 30 seconds while Chrome is running.
