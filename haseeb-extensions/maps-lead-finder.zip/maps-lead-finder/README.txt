Maps Lead Finder v1.6.0 (Chrome / Edge / Brave, Manifest V3)

=========================================================================
INSTALL (first time)
=========================================================================
1. Extract the zip to a folder you will KEEP (for example C:\Tools\maps-lead-finder). Chrome runs the extension from it.
2. Open chrome://extensions and turn on "Developer mode".
3. Click "Load unpacked" and select the folder that contains manifest.json.

=========================================================================
UPDATE (keeps your saved leads, settings and license)
=========================================================================
Saved leads, settings and the license live in Chrome's storage for this extension. An unpacked extension's ID comes
from its folder path, so:
1. Do NOT click "Remove" and do NOT load the new version from a different folder. Either one creates a fresh, empty copy.
2. Close Chrome tabs showing Maps, then copy the new files over the OLD folder (replace all files when asked).
3. Open chrome://extensions and press the circular reload arrow on the Maps Lead Finder card.
4. Reload any open Google Maps tab (F5).
If you must move the folder, press "Export CSV" first, because the moved copy starts empty.
If you replaced license-public.js, see "Owner: installing your public key" below.

=========================================================================
USE
=========================================================================
1. Open google.com/maps and search, e.g. "dentist in Rawalpindi".
2. In the panel press Start. It scrolls the results, then opens each listing to read phone and website.
3. Export CSV (opens in Excel / Google Sheets), or copy phones / emails.
   If the panel is hidden, click the extension icon and choose "Open panel on Maps".
Filters: Only with phone, Only with email, No website (hot leads).

CSV notes
- Text fields that could be read as a spreadsheet formula (start with = + - @, tab or carriage return, even after leading
  spaces) are prefixed with an apostrophe. This covers name, category, address, website, email, URLs and the search text.
- Phone numbers are written as text with their leading 0 / + kept. A phone that arrives as a bare digit run gets one space
  ("0300 1234567", "+92 3001234567") so Excel does not turn it into a number and drop the zero.
- Rating, reviews, latitude and longitude are written as numbers only when they are valid numbers.
- The file starts with a UTF-8 BOM so Excel shows non-English names correctly.

Contacting a lead (WhatsApp, Gmail, SMS, Call)
- Every lead in the panel has four buttons: WhatsApp, Gmail, SMS and Call. Click one and the app opens with the message
  already filled in; YOU press send (or dial). Nothing is sent automatically and there is no bulk sending: one lead at a time.
  * WhatsApp opens a wa.me link (WhatsApp Web or the desktop app) with your text.
  * Gmail opens a Gmail draft (mail.google.com) with recipient, subject and text. It uses the Google account that is
    signed in to Gmail in that browser.
  * SMS and Call use sms: and tel: links. They work on a phone, or on a PC with Phone Link / a calling app. If no app is
    set up, Chrome may ask which app to use or do nothing.
  A button is greyed out when the lead has no valid phone (WhatsApp, SMS, Call) or no email (Gmail).
- Message templates: open "Message templates" in the panel. Use {name}, {category} and {sender} (your name or business,
  set once). "Reset templates" restores the defaults. Edit the defaults to suit you before you start.
- The panel remembers which buttons you opened for each lead and shows "Opened: WhatsApp, Gmail". Tick "Hide leads I already
  contacted" to avoid messaging the same business twice. This records that you opened the button, not that you sent anything.
- Be considerate: WhatsApp can restrict accounts that message many strangers, so go slowly and keep messages short and
  relevant. Always give people an easy way to say no, and don't contact someone who has asked you to stop.

WhatsApp column in the CSV
- The CSV has a wa.me link built from the phone number and your country code (default 92). Numbers are normalised the same
  way everywhere: 0300 1234567, +92 3001234567, 0092 3001234567 and 923001234567 all give 923001234567; valid numbers from
  other countries are kept. A well-formed link does NOT mean that number has a WhatsApp account.

Email
- Google Maps does not show emails. The extension looks on the business website (homepage, then contact/about page).
- Only same-site pages are read, only public http(s) addresses are allowed (no localhost, private or link-local addresses,
  IPv4 or IPv6), downloads stop at about 1.5 MB, and no cookies are sent.
- Redirects are not followed blindly. Chrome does not let an extension read where a redirect points, so such a site is
  retried only at a few predictable, individually checked addresses (https, www on/off). Sites that redirect somewhere else
  (for example to /en/) may therefore return no email.
- A website name that resolves to a private address through DNS cannot be detected by an extension (DNS rebinding is not
  covered).

=========================================================================
LICENSING
=========================================================================
Each copy works only for the Google account signed in to that Chrome profile, with a license key issued for that exact
email. This prevents casual sharing. It is NOT tamper-proof: the code runs on the customer's computer, so a technical
person can edit it out. For strong protection you need a server.

Release vs owner copy vs development
- CUSTOMER RELEASE: a valid PUBLIC key is baked into license-public.js. Pasting a key into the panel can never override it,
  and the panel shows only the license box.
- NO KEY INSTALLED: the panel says "License configuration required" and stays locked (the license box is greyed out). The
  OWNER can finish setup right there in "Owner setup": paste the text of license-public.js or press "Choose file...", then
  "Save setup". Then paste a license key for your own Chrome account and press Activate. The copy is marked "owner copy".
  Only the PUBLIC key goes in that box. The private key is never needed by the extension and is never entered here: it
  stays in your License Control Panel. "Remove setup" (owner copy only) clears it again.
- Always give customers a folder that already contains your license-public.js. A copy shipped without it would let whoever
  holds it paste in a public key of their own.
- LF_MODE = "development" in license-public.js labels the copy DEVELOPMENT (testing only, never for customers).
- A public key that contains private material is rejected.

Owner: installing your EXISTING public key (no new keys are created)
Option A (for customers' copies): 1. Open your license control panel and press Setup > "Load private key file" (your existing
   license-private-key.json). Do NOT press "Generate new keys": that would invalidate every license already issued.
   2. Press "Download license-public.js". 3. Copy that file into this extension folder, replacing the existing
   license-public.js. 4. Reload the extension at chrome://extensions.
Option B (your own copy, quickest): open the panel on Maps, use Owner setup > "Choose file..." and pick that same
   license-public.js (or paste its text), then Save setup.

Activating a license (customer)
- The panel shows the customer's Chrome email (with a Copy button). They send it to you, you issue a key for that email, they
  paste it (or press Paste) and press Activate. "Deactivate" in the panel removes the license from that browser. A key is checked completely (signature, structure, account, expiry, ON/OFF status) BEFORE it is saved, so a
  wrong, expired or tampered key never replaces a license that already works.
- The Chrome profile must be signed in with the licensed Google account. If no email is available the panel says so.

ON/OFF control
- Optional. Host the signed status.json from the control panel and put its https address in the panel's Status URL, then
  download license-public.js again. Customers are locked out within about 10 minutes of you uploading a new status file.
  If the file cannot be reached, copies keep working for up to 72 hours after their last successful check.

=========================================================================
NOTES
=========================================================================
- Google changes Maps class names now and then. If something stops working, fix the selectors in the SEL object at the top of
  content.js. Live Google Maps behaviour has to be checked in a real browser after each Maps change.
- Emails are public contact addresses. Keep messages short and relevant, don't send in bulk, and give people a way to opt out.
